<?php

$token = "8180404852:AAFY_teDRukAKasbnHUQoyVBMI4OLhgkPLE";
$chatid= "-4572668478";         


?>