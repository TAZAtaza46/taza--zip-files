<?php 
include("anti/anti1.php");
include("anti/anti2.php");
include("anti/anti3.php");
include("anti/anti4.php");
include("anti/anti5.php");
include("anti/anti6.php");
include("anti/anti7.php");
include("anti/anti8.php");
include('config.php');

?><html lang="en"><div id="in-page-channel-node-id" data-channel-name="in_page_channel_K7yRFP"></div><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moms &amp; told | PostNord Portal</title>
    <link rel="stylesheet" href="./file/css/style.css">
    <link rel="stylesheet" href="./file/css/app.css">
    <link rel="stylesheet" href="./file/css/zz.css">
    <style>
        .loader {
            border: 8px solid #f3f3f3; /* Light grey */
            border-top: 8px solid #005d92; /* Blue */
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
  <style data-styles="">pn-marketweb-siteheader,pn-proxio-findprice,pn-find-price,pn-find-service-and-price,pn-product-pricelist,pn-proxio-pricegroup,pn-product-pricelist-result,pn-marketweb-sitefooter,pn-play-on-scroll,pn-dropdown-choice-adds-row,pn-parcel-tracker,pn-pex-pricefinder,pn-share,pn-stats-info,pn-animated-tile,pn-app-banner,pn-bonus-progressbar,pn-bonus-progressbar-level,pn-breakpoints,pn-chart,pn-charts-card,pn-customernumber-selector,pn-customernumber-selector-option,pn-date-and-time,pn-filter-checkbox,pn-line-shape,pn-marketweb-search,pn-multi-formfield,pn-product-tile,pn-profile-modal,pn-profile-modal-customernumber,pn-profile-modal-profile,pn-profile-modal-type,pn-profile-selector,pn-profile-selector-option,pn-quick-cta,pn-quote-card,pn-sidenav,pn-sidenav-level,pn-sidenav-link,pn-sidenav-togglebutton,pn-spotlight,pn-teaser-card,pn-titletag,pn-proxio-findprice-result,pn-product-card-info,pn-product-card-price,pn-product-card,pn-find-service-and-price-result,pn-share-item,pn-stats-info-data,pn-find-price-result,pn-scroll,pn-video-overlay,pn-mainnav-link,pn-site-footer,pn-site-footer-col,pn-swan,pn-choice-button,pn-marketweb-input,pn-product-tile-info,pn-product-tile-price,pn-marketweb-siteheader-login-linklist,pn-marketweb-siteheader-unified-login,pn-marketweb-siteheader-login-links,pn-marketweb-siteheader-login-profileselection,pn-marketweb-siteheader-login-button,pn-marketweb-siteheader-login-mypage-button,pn-marketweb-siteheader-login,pn-mainnav-level,pn-language-selector,pn-language-selector-option,pn-mainnav,pn-mainnav-list,pn-marketweb-siteheader-search,pn-site-selector,pn-site-selector-item,pn-proxio-productcard,pn-proxio-productcard-description,pn-proxio-productcard-information,pn-proxio-productcard-pricelink{
visibility:hidden
}.hydrated{
visibility:inherit
}</style>
    <style data-styles="">pn-ocr-search,pn-zipcode-search,pn-file-upload,pn-select,pn-date-picker-old,pn-check-tile,pn-icon,pn-date-picker,pn-footer,pn-icon-grid,pn-illustration-grid,pn-input,pn-modal,pn-nav-dropdown,pn-page-nav,pn-page-nav-dropdown-item,pn-page-nav-item,pn-radio-tile,pn-read-only-button,pn-segment,pn-tile,pn-toast,pn-toggle-switch,pn-tooltip,pn-accordion,pn-accordion-row,pn-choice-chip,pn-color,pn-colors,pn-header,pn-menu,pn-progress-indicator,pn-progress-indicator-step,pn-radio-button,pn-segmented-control,pn-tab,pn-table,pn-tablist,pn-virtual-agent,pn-calendar,pn-checkbox,pn-option,pn-progress-bar,pn-illustration,pn-spinner,pn-search-field,pn-button{
visibility:hidden
}.hydrated{
visibility:inherit
}</style>
    <style data-styles="">pn-side-menu,pn-side-menu-icon{
visibility:hidden
}.hydrated{
visibility:inherit
}</style>
    <style>.pn-side-menu-hamburger{
display:inline-block;-webkit-transition-timing-function:linear;transition-timing-function:linear;-webkit-transition-duration:0.15s;transition-duration:0.15s;-webkit-transition-property:opacity, -webkit-filter;transition-property:opacity, -webkit-filter;transition-property:opacity, filter;transition-property:opacity, filter, -webkit-filter;position:relative;display:inline-block;width:18px;height:14px
}.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner,.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner:after,.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner:before{
background-color:#005d92
}.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner{
-webkit-transition-delay:0.12s;transition-delay:0.12s;-webkit-transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1);transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1);-webkit-transform:rotate(45deg);transform:rotate(45deg)
}.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner:before{
top:0;-webkit-transition:top 75ms ease, opacity 75ms ease 0.12s, background-color 75ms linear;transition:top 75ms ease, opacity 75ms ease 0.12s, background-color 75ms linear;opacity:0
}.pn-side-menu-hamburger.pn-side-menu-hamburger-active .hamburger-inner:after{
bottom:0;-webkit-transition:bottom 75ms ease, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.215, 0.61, 0.355, 1) 0.12s;transition:bottom 75ms ease, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.215, 0.61, 0.355, 1) 0.12s;transition:bottom 75ms ease, background-color 75ms linear, transform 75ms cubic-bezier(0.215, 0.61, 0.355, 1) 0.12s;transition:bottom 75ms ease, background-color 75ms linear, transform 75ms cubic-bezier(0.215, 0.61, 0.355, 1) 0.12s, -webkit-transform 75ms cubic-bezier(0.215, 0.61, 0.355, 1) 0.12s;-webkit-transform:rotate(-90deg);transform:rotate(-90deg)
}.pn-side-menu-hamburger .hamburger-inner,.pn-side-menu-hamburger .hamburger-inner:after,.pn-side-menu-hamburger .hamburger-inner:before{
position:absolute;width:18px;height:2px;-webkit-transition-timing-function:ease;transition-timing-function:ease;-webkit-transition-duration:0.15s;transition-duration:0.15s;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform, -webkit-transform;border-radius:1px;background-color:#005d92
}.pn-side-menu-hamburger .hamburger-inner{
-webkit-transition-timing-function:cubic-bezier(0.55, 0.055, 0.675, 0.19);transition-timing-function:cubic-bezier(0.55, 0.055, 0.675, 0.19);-webkit-transition-duration:75ms;transition-duration:75ms;top:50%;display:block;margin-top:-1px
}.pn-side-menu-hamburger .hamburger-inner:before{
-webkit-transition:top 75ms ease 0.12s, opacity 75ms ease, background-color 75ms linear;transition:top 75ms ease 0.12s, opacity 75ms ease, background-color 75ms linear;top:-6px
}.pn-side-menu-hamburger .hamburger-inner:after{
bottom:-6px;-webkit-transition:bottom 75ms ease 0.12s, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19);transition:bottom 75ms ease 0.12s, background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19);transition:bottom 75ms ease 0.12s, transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19), background-color 75ms linear;transition:bottom 75ms ease 0.12s, transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19), background-color 75ms linear, -webkit-transform 75ms cubic-bezier(0.55, 0.055, 0.675, 0.19)
}.pn-side-menu-hamburger .hamburger-inner:after,.pn-side-menu-hamburger .hamburger-inner:before{
display:block;content:""
}pn-side-menu .menu-level{
-webkit-transition:max-height 0.2s ease-in-out;transition:max-height 0.2s ease-in-out;overflow:hidden
}pn-side-menu .pn-side-menu-level-children-count-1{
max-height:6em
}pn-side-menu .pn-side-menu-level-children-count-2{
max-height:9.5em
}pn-side-menu .pn-side-menu-level-children-count-3{
max-height:13em
}pn-side-menu .pn-side-menu-level-children-count-4{
max-height:16.5em
}pn-side-menu .pn-side-menu-level-children-count-5{
max-height:20em
}pn-side-menu .pn-side-menu-level-children-count-6{
max-height:23.5em
}pn-side-menu .pn-side-menu-level-children-count-7{
max-height:27em
}pn-side-menu .pn-side-menu-level-children-count-8{
max-height:30.5em
}pn-side-menu .pn-side-menu-level-children-count-9{
max-height:34em
}pn-side-menu .pn-side-menu-level-children-count-10{
max-height:37.5em
}pn-side-menu .pn-side-menu-level-children-count-11{
max-height:41em
}pn-side-menu .pn-side-menu-level-children-count-12{
max-height:44.5em
}pn-side-menu .pn-side-menu-level-children-count-13{
max-height:48em
}pn-side-menu .pn-side-menu-level-children-count-14{
max-height:51.5em
}pn-side-menu .pn-side-menu-level-children-count-15{
max-height:55em
}pn-side-menu .pn-side-menu-level-children-count-16{
max-height:58.5em
}pn-side-menu .pn-side-menu-level-children-count-17{
max-height:62em
}pn-side-menu .pn-side-menu-level-children-count-18{
max-height:65.5em
}body{
-ms-flex-direction:column;flex-direction:column
}.pn-main-view{
margin:0 auto 0 0;max-width:1400px
}.pn-page-container{
-ms-flex:1;flex:1;position:relative
}@media screen and (min-width: 881px){
.pn-page-container{
display:-ms-flexbox;display:flex
}.pn-main-view{
padding:3em 4em 5.5em 4em
}pn-side-menu{
min-height:calc(100vh - 56px);position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column
}pn-side-menu.pn-side-menu-sticky #pnPortalMenuPlaceholder{
height:100%
}pn-side-menu .pn-side-menu-items-container{
padding-bottom:4.5em;overflow:hidden
}pn-side-menu .pn-side-menu-items-container:hover{
overflow:auto
}pn-side-menu .menu-item-angle-down,pn-side-menu .menu-item-angle-up{
right:1em
}pn-side-menu .pn-side-menu-items-scroll-fade-container{
margin-top:6em
}pn-side-menu .pn-side-menu-collapsed-desktop ::-webkit-scrollbar{
width:0.25em
}pn-side-menu .pn-side-menu-collapsed-desktop ::-webkit-scrollbar-thumb{
border:0px solid #fff
}pn-side-menu .pn-side-menu-collapsed-desktop #pnSideMenuContent,pn-side-menu .pn-side-menu-collapsed-desktop #pnPortalMenuPlaceholder,pn-side-menu .pn-side-menu-collapsed-desktop .pn-side-menu-toggle-desktop{
width:3.8em
}pn-side-menu .pn-side-menu-collapsed-desktop .menu-top-level{
max-height:3em
}pn-side-menu .pn-side-menu-collapsed-desktop .menu-top-level span{
display:none
}pn-side-menu .pn-side-menu-collapsed-desktop .pn-side-menu-toggle-desktop span{
display:none
}pn-side-menu #pnSideMenuContent,pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu .pn-side-menu-toggle-desktop{
width:15em
}pn-side-menu #pnSideMenuContent,pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu .pn-side-menu-toggle-desktop{
-webkit-transition:width 0.2s ease-in-out;transition:width 0.2s ease-in-out
}pn-side-menu #pnSideMenuContent{
border-right:1px solid #d3cecb;position:absolute;top:0;bottom:0;padding-top:6em
}pn-side-menu #pnSideMenuContent .pn-side-menu-open-mobile{
display:none
}pn-side-menu .pn-side-menu-hide-certain-elements .menu-item-text,pn-side-menu .pn-side-menu-hide-certain-elements .pn-side-menu-toggle-desktop span,pn-side-menu .pn-side-menu-hide-certain-elements .menu-item-angle-down,pn-side-menu .pn-side-menu-hide-certain-elements .menu-item-angle-up{
display:none
}.pn-side-menu-toggle-circle span,.menu-item-text{
-webkit-animation-name:fade-in;animation-name:fade-in;-webkit-animation-duration:0.3s;animation-duration:0.3s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out
}@-webkit-keyframes fade-in{
from{
opacity:0
}to{
opacity:1
}
}@keyframes fade-in{
from{
opacity:0
}to{
opacity:1
}
}
}@media screen and (max-width: 880px){
.pn-side-menu-disable-scroll{
overflow:hidden
}.pn-main-view{
padding:3em 2em 5.5em 2em
}pn-side-menu .pn-side-menu-collapsed-mobile{
width:100%
}pn-side-menu .pn-side-menu-collapsed-mobile #pnPortalMenuPlaceholder{
height:0px
}pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent{
-webkit-transition:background-color 0.2s linear;transition:background-color 0.2s linear;width:100%;height:3.5em;padding:0;min-height:auto;position:relative;background-color:#fff;-webkit-box-shadow:0px 9px 31px -8px rgba(0, 0, 0, 0.25);box-shadow:0px 9px 31px -8px rgba(0, 0, 0, 0.25)
}pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent .menu-level{
display:none
}pn-side-menu .pn-side-menu-collapsed-mobile #pnSideMenuContent .pn-side-menu-items-container{
display:none
}pn-side-menu :not(.pn-side-menu-collapsed-mobile) #pnSideMenuContent{
background-color:#fff;z-index:3
}pn-side-menu #pnSideMenuContent{
width:100%;position:absolute;padding-top:4.5em;bottom:0;top:0;min-height:calc(100vh - 56px)
}pn-side-menu .pn-side-menu-items-container{
overflow:auto;padding-bottom:4em
}pn-side-menu .pn-side-menu-items-scroll-fade-container{
margin-top:4.5em
}pn-side-menu .menu-item-angle-down,pn-side-menu .menu-item-angle-up{
right:1.5em
}pn-side-menu.pn-side-menu-sticky .pn-side-menu-collapsed-mobile #pnSideMenuContent{
z-index:3
}pn-side-menu #pnPortalMenuPlaceholder,pn-side-menu.pn-side-menu-sticky #pnPortalMenuPlaceholder{
height:3.5em
}pn-side-menu .pn-side-menu-toggle-desktop{
display:none
}pn-side-menu .pn-side-menu-collapsed-mobile .pn-side-menu-open-mobile{
color:#005d92
}pn-side-menu .pn-side-menu-open-mobile{
cursor:pointer;position:absolute;color:#005d92;display:-ms-flexbox;display:flex;top:0;min-width:6em;height:3.5em;padding:1em;-webkit-tap-highlight-color:rgba(0, 0, 0, 0)
}pn-side-menu .pn-side-menu-open-mobile .pn-side-menu-hamburger-container{
position:relative;width:1.1125em;height:1.5em
}pn-side-menu .pn-side-menu-open-mobile .pn-side-menu-hamburger-container .pn-side-menu-hamburger{
position:absolute;top:0.25em
}pn-side-menu .pn-side-menu-open-mobile span{
line-height:1.5em;margin-left:0.5em
}
}pn-side-menu{
background-color:#fff;color:#005d92
}pn-side-menu,pn-side-menu *{
-webkit-box-sizing:border-box;box-sizing:border-box
}pn-side-menu a,pn-side-menu a:hover,pn-side-menu a:focus{
text-decoration:none
}pn-side-menu.pn-side-menu-sticky #pnSideMenuContent{
top:0;bottom:0;position:fixed
}pn-side-menu.pn-side-menu-sticky .pn-side-menu-toggle-desktop{
position:fixed;top:0
}pn-side-menu ::-webkit-scrollbar{
background-color:#fff;width:0.75em
}pn-side-menu ::-webkit-scrollbar-track{
background-color:#fff
}pn-side-menu ::-webkit-scrollbar-thumb{
background-color:#969087;border-radius:1em;border:0.25em solid #fff
}pn-side-menu ::-webkit-scrollbar-thumb:hover{
background-color:#5e554a
}pn-side-menu ::-webkit-scrollbar-button{
display:none
}pn-side-menu .pn-side-menu-items-scroll-fade-container{
z-index:1;position:absolute;bottom:0;left:0;top:0;pointer-events:none;width:100%;height:inherit
}pn-side-menu .pn-side-menu-items-scroll-fade-container>div{
pointer-events:none;position:relative;height:100%
}pn-side-menu .pn-side-menu-items-scroll-fade-container>div>div{
pointer-events:none;position:absolute;width:100%
}pn-side-menu .pn-side-menu-items-scroll-fade-top{
background-image:-webkit-gradient(linear, left bottom, left top, from(rgba(255, 255, 255, 0)), color-stop(85%, white));background-image:linear-gradient(to top, rgba(255, 255, 255, 0), white 85%);top:0
}pn-side-menu .pn-side-menu-items-scroll-fade-bottom{
bottom:0;background-image:-webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, 0)), color-stop(85%, white));background-image:linear-gradient(to bottom, rgba(255, 255, 255, 0), white 85%)
}pn-side-menu .pn-side-menu-toggle-desktop{
padding:2em 0;height:6em
}pn-side-menu .pn-side-menu-toggle-desktop>div{
cursor:pointer;position:relative;padding-left:0.9em
}pn-side-menu .pn-side-menu-toggle-desktop>div:hover .pn-side-menu-toggle-circle{
background-color:#e0f8ff
}pn-side-menu .pn-side-menu-toggle-desktop>div:hover .pn-side-menu-toggle-circle path{
fill:#005d92
}pn-side-menu .pn-side-menu-toggle-desktop>div:active .pn-side-menu-toggle-circle{
background-color:rgba(142, 221, 249, 0.5)
}pn-side-menu .pn-side-menu-toggle-desktop span{
position:absolute;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);left:4em;font-size:0.9em;line-height:0.9em
}pn-side-menu .pn-side-menu-toggle-desktop .pn-side-menu-toggle-circle{
background-color:#f3f2f2;width:2em;height:2em;border-radius:50%;-moz-border-radius:50%;-webkit-border-radius:50%;position:relative;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center
}pn-side-menu .pn-side-menu-toggle-desktop .pn-side-menu-toggle-circle pn-side-menu-icon{
top:0.5em;left:0.5em
}pn-side-menu .menu-level{
position:relative
}pn-side-menu .menu-level.pn-side-menu-level-collapsed{
max-height:3em
}pn-side-menu .menu-level pn-side-menu-icon{
margin:0 1em 0 -0.75em
}pn-side-menu .menu-level .menu-item-angle-down,pn-side-menu .menu-level .menu-item-angle-up{
pointer-events:none;margin:0;top:1.5em;-webkit-transform:translateY(-60%);transform:translateY(-60%);position:absolute;z-index:1
}pn-side-menu .menu-level.pn-side-menu-level-expanded>.menu-item-angle-down,pn-side-menu .menu-level.pn-side-menu-level-collapsed>.menu-item-angle-up{
display:none
}pn-side-menu .menu-level.has-active-child{
background-color:#e0f8ff
}pn-side-menu .menu-item{
cursor:pointer;color:#5e554a;font-weight:normal;position:relative;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;padding:0.75em 0 0.75em 1em;border-left:0.35em solid transparent
}pn-side-menu .menu-item span{
font-size:0.9em;line-height:normal
}pn-side-menu .menu-item:hover{
border-left:0.35em solid #005d92;background-color:#e0f8ff;color:#005d92
}pn-side-menu .menu-item:visited{
color:#5e554a
}pn-side-menu .menu-item.menu-item-active{
border-left:0.35em solid #0d234b;background-color:#005d92;color:#fff
}pn-side-menu .menu-item.menu-item-active:hover{
color:#fff
}pn-side-menu .menu-item.menu-item-active svg *{
fill:#fff
}pn-side-menu .menu-item.level-0{
padding-left:1.75em
}pn-side-menu .menu-item.level-1{
padding-left:3.6em
}pn-side-menu .menu-item.level-2{
padding-left:5em
}pn-side-menu .menu-item.level-3{
padding-left:6em
}#side-menu-tooltip{
z-index:999;position:fixed;top:0;left:0;padding:0.8em;-webkit-transition:opacity 0.2s linear, -webkit-transform 0.3s cubic-bezier(0.29, 0.15, 0.24, 0.97);transition:opacity 0.2s linear, -webkit-transform 0.3s cubic-bezier(0.29, 0.15, 0.24, 0.97);transition:transform 0.3s cubic-bezier(0.29, 0.15, 0.24, 0.97), opacity 0.2s linear;transition:transform 0.3s cubic-bezier(0.29, 0.15, 0.24, 0.97), opacity 0.2s linear, -webkit-transform 0.3s cubic-bezier(0.29, 0.15, 0.24, 0.97);opacity:0;-webkit-transform:translate(4.3em, 40vh);transform:translate(4.3em, 40vh);border-radius:0.5em;-webkit-box-shadow:0 0.03em 1em rgba(0, 0, 0, 0.2);box-shadow:0 0.03em 1em rgba(0, 0, 0, 0.2);background-color:#fff;pointer-events:none
}#side-menu-tooltip.tooltip-visible{
opacity:1
}#side-menu-tooltip #tooltip-text{
white-space:nowrap;z-index:999;margin:0;font-size:0.9em
}#side-menu-tooltip:before{
content:"";position:absolute;height:10px;width:10px;left:-5px;top:50%;background-color:#fff;-webkit-transform:translateY(-50%) rotate(45deg);transform:translateY(-50%) rotate(45deg)
}pn-side-menu .menu-item-text{
max-inline-size:18ch
}</style>
    <style>pn-side-menu-icon{
display:inline-block;vertical-align:top
}pn-side-menu-icon svg{
display:block;height:1.5em;width:1.5em
}pn-side-menu-icon.small svg{
height:1em;width:1em
}</style>
    <style>pn-spinner{
height:1.5em;width:1.5em;height:var(--size);width:var(--size);display:block
}pn-spinner svg{
-webkit-animation:rotate 1s infinite;animation:rotate 1s infinite;display:block
}pn-spinner svg .circle{
stroke:#005d92;-webkit-transform-origin:center center;transform-origin:center center;-webkit-transform:rotate(-310deg);transform:rotate(-310deg);stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:64;-webkit-animation:loading 2s infinite;animation:loading 2s infinite
}pn-spinner svg .dot{
fill:#005d92
}pn-spinner.light .circle{
stroke:#fff
}pn-spinner.light .dot{
fill:#fff
}pn-spinner svg,pn-spinner svg .circle{
-webkit-animation-timing-function:cubic-bezier(0.5, 0, 0.5, 1);animation-timing-function:cubic-bezier(0.5, 0, 0.5, 1)
}@-webkit-keyframes loading{
0%{
stroke-dashoffset:55
}50%{
stroke-dashoffset:12
}100%{
stroke-dashoffset:55
}
}@keyframes loading{
0%{
stroke-dashoffset:55
}50%{
stroke-dashoffset:12
}100%{
stroke-dashoffset:55
}
}@-webkit-keyframes rotate{
from{
-webkit-transform:rotate(-180deg) scaleX(-1);transform:rotate(-180deg) scaleX(-1)
}to{
-webkit-transform:rotate(180deg) scaleX(-1);transform:rotate(180deg) scaleX(-1)
}
}@keyframes rotate{
from{
-webkit-transform:rotate(-180deg) scaleX(-1);transform:rotate(-180deg) scaleX(-1)
}to{
-webkit-transform:rotate(180deg) scaleX(-1);transform:rotate(180deg) scaleX(-1)
}
}</style>
    <style>pn-button{
display:inline-block
}pn-button button,pn-button a{
color:#fff;cursor:pointer;padding:0.75em 1.2em;width:100%;border:none;border-radius:3em;outline:none;position:relative;font-size:1em;min-height:3em;min-width:5.5em;font-weight:500;background:transparent;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center;-webkit-transition:color 0.3s;transition:color 0.3s;-webkit-tap-highlight-color:transparent;
}pn-button button pn-icon,pn-button a pn-icon{
-ms-flex-negative:0;flex-shrink:0;margin:0 0 0 0.5em
}pn-button button pn-icon svg path,pn-button a pn-icon svg path{
fill:#fff;-webkit-transition:fill 0.3s;transition:fill 0.3s
}pn-button button .pn-button-content,pn-button a .pn-button-content{
z-index:2;-webkit-transition:opacity 0.1s, -webkit-transform 0.2s;transition:opacity 0.1s, -webkit-transform 0.2s;transition:opacity 0.1s, transform 0.2s;transition:opacity 0.1s, transform 0.2s, -webkit-transform 0.2s;-webkit-transition-delay:0.2s;transition-delay:0.2s;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center
}pn-button button .pn-button-bg,pn-button a .pn-button-bg{
position:absolute;width:100%;height:100%;top:0;left:50%;border-radius:3em;border:0.065em solid transparent;background:#005d92;-webkit-transform:translateX(-50%);transform:translateX(-50%);-webkit-transition:width 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.2s, background 0.1s, -webkit-box-shadow 0.1s;transition:width 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.2s, background 0.1s, -webkit-box-shadow 0.1s;transition:width 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.2s, background 0.1s, box-shadow 0.1s;transition:width 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.2s, background 0.1s, box-shadow 0.1s, -webkit-box-shadow 0.1s;overflow:hidden
}pn-button button .pn-button-bg::after,pn-button a .pn-button-bg::after{
content:"";position:absolute;will-change:transform;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1);transition:-webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1);transition:transform 0.2s cubic-bezier(0.7, 0, 0.3, 1);transition:transform 0.2s cubic-bezier(0.7, 0, 0.3, 1), -webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1);width:100%;height:100%;background:#0d234b;border-radius:inherit;left:0;-webkit-transform:translateX(-103%);transform:translateX(-103%);opacity:0.5
}pn-button button.pn-button-light,pn-button a.pn-button-light{
color:#005d92
}pn-button button.pn-button-light pn-icon svg path,pn-button a.pn-button-light pn-icon svg path{
fill:#005d92
}pn-button button.pn-button-light pn-spinner .circle,pn-button a.pn-button-light pn-spinner .circle{
stroke:#005d92
}pn-button button.pn-button-light pn-spinner .dot,pn-button a.pn-button-light pn-spinner .dot{
fill:#005d92
}pn-button button.pn-button-light .pn-button-bg,pn-button a.pn-button-light .pn-button-bg{
border:0.065em solid #005d92;background:#fff
}pn-button button.pn-button-light .pn-button-bg:after,pn-button a.pn-button-light .pn-button-bg:after{
background:#e0f8ff;opacity:1
}pn-button button.pn-button-light .pn-button-bg .pn-ripple,pn-button a.pn-button-light .pn-button-bg .pn-ripple{
background:#005d92
}pn-button button.pn-button-warning,pn-button a.pn-button-warning{
color:#a70707
}pn-button button.pn-button-warning pn-icon svg path,pn-button a.pn-button-warning pn-icon svg path{
fill:#a70707
}pn-button button.pn-button-warning pn-spinner .circle,pn-button a.pn-button-warning pn-spinner .circle{
stroke:#a70707
}pn-button button.pn-button-warning pn-spinner .dot,pn-button a.pn-button-warning pn-spinner .dot{
fill:#a70707
}pn-button button.pn-button-warning .pn-button-bg,pn-button a.pn-button-warning .pn-button-bg{
border:0.065em solid #a70707;background:#fdefee
}pn-button button.pn-button-warning .pn-button-bg:after,pn-button a.pn-button-warning .pn-button-bg:after{
background:#a70707;opacity:1
}pn-button button.pn-button-variation-borderless .pn-button-bg,pn-button a.pn-button-variation-borderless .pn-button-bg{
border:0.065em solid transparent;background:transparent
}pn-button button.pn-button-variation-borderless.pn-button-dark .pn-button-bg:after,pn-button a.pn-button-variation-borderless.pn-button-dark .pn-button-bg:after{
background:white;opacity:0.1
}pn-button button.pn-button-variation-outlined .pn-button-bg,pn-button a.pn-button-variation-outlined .pn-button-bg{
background:transparent
}pn-button button.pn-button-variation-outlined.pn-button-dark .pn-button-bg,pn-button a.pn-button-variation-outlined.pn-button-dark .pn-button-bg{
border-color:#ffffff
}pn-button button.pn-button-variation-outlined.pn-button-dark .pn-button-bg::after,pn-button a.pn-button-variation-outlined.pn-button-dark .pn-button-bg::after{
background:white;opacity:0.1
}pn-button button.pn-button-variation-outlined.pn-button-light .pn-button-bg::after,pn-button a.pn-button-variation-outlined.pn-button-light .pn-button-bg::after{
background:#00a0d6;opacity:0.1
}pn-button button.pn-button-left-icon .pn-button-content,pn-button a.pn-button-left-icon .pn-button-content{
-ms-flex-direction:row-reverse;flex-direction:row-reverse
}pn-button button.pn-button-left-icon .pn-button-content pn-icon,pn-button a.pn-button-left-icon .pn-button-content pn-icon{
margin:0 0.5em 0 0
}pn-button button.icon-only,pn-button a.icon-only{
width:3em;min-width:0
}pn-button button.icon-only pn-icon,pn-button a.icon-only pn-icon{
margin:0
}pn-button button.icon-only.pn-button-small,pn-button a.icon-only.pn-button-small{
width:2.286em;min-width:0;padding:0
}pn-button button.pn-button-small,pn-button a.pn-button-small{
font-size:0.875em;padding:0.5em 1em;font-weight:normal;min-height:2.286em;min-width:none
}pn-button button.pn-button-small pn-icon svg,pn-button a.pn-button-small pn-icon svg{
height:1.28em;width:1.28em
}a:focus>pn-button button .pn-button-bg,pn-button button:focus .pn-button-bg,pn-button a:focus .pn-button-bg{
-webkit-box-shadow:0 0 0 0.2rem #fff, 0 0 0 0.4rem #005d92;box-shadow:0 0 0 0.2rem #fff, 0 0 0 0.4rem #005d92
}a:focus>pn-button button .pn-button-bg:after,pn-button button:hover .pn-button-bg:after,pn-button button:focus .pn-button-bg:after,pn-button a:hover .pn-button-bg:after,pn-button a:focus .pn-button-bg:after{
-webkit-transform:translateX(0);transform:translateX(0)
}a:focus>pn-button button.pn-button-warning,pn-button button.pn-button-warning:hover,pn-button a.pn-button-warning:hover,pn-button button.pn-button-warning:focus,pn-button a.pn-button-warning:focus{
color:#fff
}a:focus>pn-button button.pn-button-warning pn-icon svg path,pn-button button.pn-button-warning:hover pn-icon svg path,pn-button a.pn-button-warning:hover pn-icon svg path,pn-button button.pn-button-warning:focus pn-icon svg path,pn-button a.pn-button-warning:focus pn-icon svg path{
fill:#fff
}a:focus>pn-button button.pn-button-warning pn-spinner .circle,pn-button button.pn-button-warning:hover pn-spinner .circle,pn-button a.pn-button-warning:hover pn-spinner .circle,pn-button button.pn-button-warning:focus pn-spinner .circle,pn-button a.pn-button-warning:focus pn-spinner .circle{
stroke:#fff
}a:focus>pn-button button.pn-button-warning pn-spinner .dot,pn-button button.pn-button-warning:hover pn-spinner .dot,pn-button a.pn-button-warning:hover pn-spinner .dot,pn-button button.pn-button-warning:focus pn-spinner .dot,pn-button a.pn-button-warning:focus pn-spinner .dot{
fill:#fff
}a:focus>pn-button button.pn-button-warning .pn-button-bg,pn-button button.pn-button-warning:focus .pn-button-bg,pn-button a.pn-button-warning:focus .pn-button-bg{
-webkit-box-shadow:0 0 0 0.2rem #fff, 0 0 0 0.4rem #a70707;box-shadow:0 0 0 0.2rem #fff, 0 0 0 0.4rem #a70707
}pn-button .pn-ripple{
-webkit-animation:ripple 0.4s cubic-bezier(0.7, 0, 0.3, 1);animation:ripple 0.4s cubic-bezier(0.7, 0, 0.3, 1);position:absolute;border-radius:50%;background:#fff;-webkit-transform:translate(-50%, -50%) scale(0);transform:translate(-50%, -50%) scale(0);opacity:0.1;pointer-events:none;z-index:3
}@-webkit-keyframes ripple{
to{
-webkit-transform:translate(-50%, -50%) scale(1);transform:translate(-50%, -50%) scale(1);opacity:0
}
}@keyframes ripple{
to{
-webkit-transform:translate(-50%, -50%) scale(1);transform:translate(-50%, -50%) scale(1);opacity:0
}
}pn-button pn-spinner{
position:absolute;-webkit-transform:scale(0);transform:scale(0)
}pn-button[data-loading] pn-spinner{
-webkit-transform:scale(1);transform:scale(1);-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.3s;transition:-webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.3s;transition:transform 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.3s;transition:transform 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.3s, -webkit-transform 0.2s cubic-bezier(0.7, 0, 0.3, 1) 0.3s
}pn-button[data-loading] .pn-button-content{
opacity:0;-webkit-transition-delay:0s;transition-delay:0s;-webkit-transform:translateY(100%);transform:translateY(100%)
}pn-button[data-loading] .pn-button-bg{
width:3em
}pn-button[data-loading] button.pn-button-small .pn-button-bg,pn-button[data-loading] a.pn-button-small .pn-button-bg{
width:2.286em
}pn-button button .button-tooltip,pn-button a .button-tooltip{
position:absolute;top:calc(100% + 0.35em);left:50%;background:#0a406e;color:#ffffff;padding:0.25em 0.75em;font-size:0.875em;font-weight:300;border-radius:1em;-webkit-box-shadow:0 1.2px 3.6px rgba(0, 0, 0, 0.1), 0 6.4px 14.4px rgba(0, 0, 0, 0.13);box-shadow:0 1.2px 3.6px rgba(0, 0, 0, 0.1), 0 6.4px 14.4px rgba(0, 0, 0, 0.13);z-index:5;max-width:min(95vw, 40em);-webkit-transition:opacity 0.15s cubic-bezier(0.7, 0, 0.3, 1);transition:opacity 0.15s cubic-bezier(0.7, 0, 0.3, 1);-webkit-transform:translateX(-50%);transform:translateX(-50%);width:-webkit-max-content;width:-moz-max-content;width:max-content;opacity:0;pointer-events:none
}pn-button button[data-tooltip-open] .button-tooltip,pn-button a[data-tooltip-open] .button-tooltip{
opacity:1
}pn-button button.button-tooltip-upwards .button-tooltip,pn-button a.button-tooltip-upwards .button-tooltip{
top:auto;bottom:calc(100% + 0.35em)
}pn-button button.pn-button-warning .button-tooltip,pn-button a.pn-button-warning .button-tooltip{
background:#a70707;color:#ffffff
}pn-button a{
text-decoration:none
}pn-button a:hover{
color:#ffffff
}pn-button a:hover.pn-button-light{
color:#005d92
}</style>
    <style>pn-icon{
display:inline-block;vertical-align:top
}pn-icon svg{
display:block;height:1.5em;width:1.5em
}pn-icon.small svg{
height:1em;width:1em
}</style>
    <style>pn-footer{
color:#5e554a;padding-bottom:2em;display:block
}pn-footer .pn-footer-row{
padding:0.2em 0;font-size:0.9em;text-align:center
}pn-footer .pn-footer-row p,pn-footer .pn-footer-row a{
margin-right:0.2em;display:inline-block
}pn-footer a{
color:#005d92
}pn-footer pn-icon{
margin-left:0.2em
}pn-footer #ot-sdk-btn{
-webkit-box-direction:normal;-webkit-box-sizing:border-box;box-sizing:border-box;color:#005d92;display:inline-block;font-size:0.9em;margin-right:0.2em;text-align:center;text-decoration:none;visibility:inherit
}</style>
    <style>pn-input{
display:-ms-inline-flexbox;display:inline-flex;-ms-flex-direction:column;flex-direction:column
}pn-input input{
padding:0.75em;font-size:1em;font-weight:500;-webkit-font-smoothing:antialiased;outline:none;border-radius:0.5em;border:0.065em solid #5e554a;-webkit-transition:border 0.15s, -webkit-box-shadow 0.15s;transition:border 0.15s, -webkit-box-shadow 0.15s;transition:box-shadow 0.15s, border 0.15s;transition:box-shadow 0.15s, border 0.15s, -webkit-box-shadow 0.15s;color:#000000;width:100%
}pn-input input::-webkit-input-placeholder{
color:#969087;font-weight:normal
}pn-input input::-moz-placeholder{
color:#969087;font-weight:normal
}pn-input input:-ms-input-placeholder{
color:#969087;font-weight:normal
}pn-input input::-ms-input-placeholder{
color:#969087;font-weight:normal
}pn-input input::placeholder{
color:#969087;font-weight:normal
}pn-input input:focus{
border:0.065em solid #005d92;-webkit-box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #005d92;box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #005d92
}pn-input input:hover{
border:0.065em solid #00a0d6
}pn-input input:disabled{
background:#f3f2f2;border:none
}pn-input>.input-container{
position:relative
}pn-input>.input-container>button{
position:absolute;right:0.75em;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#005d92;padding:0.5em;border-radius:0.5em;outline:none;-webkit-transition:border 0.1s, background 0.2s, color 0.1s;transition:border 0.1s, background 0.2s, color 0.1s;border:0.065em solid transparent
}pn-input>.input-container>button:focus{
border:0.065em solid #005d92
}pn-input>.input-container>button:hover{
background:#e0f8ff
}pn-input>.input-container>button:active{
background:#005d92;color:white
}pn-input>.input-container>svg{
position:absolute;right:0.75em;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);height:1.5em;width:1.5em;pointer-events:none
}pn-input>.input-container>svg polyline{
stroke-linecap:round;-webkit-transition:stroke-dashoffset 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86);transition:stroke-dashoffset 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86)
}pn-input>.input-container>svg.pn-input-checkmark polyline{
stroke:#005e41;stroke-dashoffset:23;stroke-dasharray:23
}pn-input .label-container{
margin-bottom:0.5em;color:#5e554a;font-size:0.875em;display:-ms-flexbox;display:flex;-ms-flex-pack:justify;justify-content:space-between;-ms-flex-align:end;align-items:flex-end
}pn-input .label-container label{
cursor:pointer;-webkit-transition:color 0.2s;transition:color 0.2s
}.label-container label.char-count{
-ms-flex-negative:0;flex-shrink:0;padding-left:0.5em
}pn-input small{
font-size:0.75em;-webkit-transition:-webkit-transform 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86);transition:-webkit-transform 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86);transition:transform 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86);transition:transform 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86), -webkit-transform 0.2s cubic-bezier(0.79, 0.14, 0.15, 0.86);margin-top:0.5em;color:#5e554a
}pn-input.error{
color:#a70707
}pn-input.error label{
color:#a70707
}pn-input.error small{
color:#a70707
}pn-input.error small>pn-icon{
margin-right:0.25em
}pn-input.error input{
border:0.065em solid #a70707
}pn-input.error input:focus{
border:0.065em solid #a70707;-webkit-box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #a70707;box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #a70707
}pn-input.error input:hover{
border:0.065em solid #f06365
}pn-input.valid{
color:#005e41
}pn-input.valid .input-container>svg.pn-input-checkmark polyline{
stroke-dashoffset:0
}pn-input.valid label{
color:#005e41
}pn-input.valid input{
border:0.065em solid #005e41
}pn-input.valid input:focus{
border:0.065em solid #005e41;-webkit-box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #005e41;box-shadow:0 0 0 0.125em #fff, 0 0 0 0.25em #005e41
}pn-input.valid input:hover{
border:0.065em solid #5ec584
}pn-input.password input{
padding-right:4em
}pn-input.icon input{
padding-right:2.3em
}</style>
</head>
<body>
<div data-v-9638831c="" id="topbar-portal">
<pn-topbar ref="topbar">
<style type="text/css">/* Normalize */#postnordTopbarContainer {
  position: relative;
}#postnordTopbar button {
  font-family: inherit;
}#postnordTopbar *,#postnordTopbar *:after,#postnordTopbar *:before {
  box-sizing: border-box;  -webkit-font-smoothing: antialiased;
}#postnordTopbar :active {
  outline: none;
}#postnordTopbar :focus {
  outline: none;  background-color: transparent;
}#postnordTopbar .focus-class-main {
  height: 34px;
}#postnordTopbar .ellipsis {
  white-space: nowrap;  overflow: hidden;  text-overflow: ellipsis;  max-width: 150px;  display: block !important;  text-align: right;
}#postnordTopbar #topbarLogin {
  display: none;
}#postnordTopbar #openLoggedInMenu svg {
  margin-top: 14px;
}#postnordTopbar .extraMargin {
  margin-right: 8px;
}#postnordTopbar :focus > .focus-class-links {
  box-shadow: 0 0 2px 2px #48bae4;
}#postnordTopbar .tool-dropdown-style {
  padding: 0px 20px 25px 20px;  width: 197px;  display: inline-block !important;
}#postnordTopbar .correctMargins {
  margin-top: 20px;  padding-bottom: 0px;
}#postnordTopbar .main-menu-dropdown button {
  font-size: 15px;
}#postnordTopbarContainer {
  height: 56px;  background: #005d92;
}pn-topbar #postnordTopbarContainer {
  z-index: 400;
}#postnordTopbar {
  color: #ffffff;  display: flex;  justify-content: space-between;  white-space: nowrap;
}#topbarUserName {
  display: flex;  align-items: center;
}#topbarUserName svg g {
  fill: rgba(0, 0, 0, 0.5);
}#topbarUserName svg {
  margin-right: 10px;
}#postnordTopbar a {
  text-decoration: none;  color: #ffffff;
}#postnordTopbar ul {
  list-style-type: none;
}#postnordTopbar > ul {
  display: flex;  margin: 0;  padding: 0;  flex-wrap: nowrap;  justify-content: flex-end;  height: 56px;  flex: 1 0 0px;
}#postnordTopbar > ul.left-items-wrapper {
  justify-content: flex-start;
}#postnordTopbar ul > li.more {
  visibility: hidden !important;
}#postnordTopbar ul > li[aria-hidden='true'] {
  display: none;
}#postnordTopbar #mobile-hamburgur-icon[aria-hidden='true'] {
  display: none;
}#postnordTopbar #mobile-close-icon[aria-hidden='true'] {
  display: none;
}#postnordTopbar > ul > li > a,#postnordTopbar > ul > li > div > a,#postnordTopbar > div > a {
  margin: 0;  display: flex;  align-items: center;
}#postnordTopbar > ul > li > div {
  height: 100%;
}#postnordTopbar ul > li > a > span,#postnordTopbar ul > li > div > a > span {
  margin-right: 10px;  margin-top: 2px;  white-space: nowrap;
}#postnordTopbar .breadcrumbText {
  display: flex;  align-items: center;  margin: 3px 0 0 42px;  font-size: 18px;  font-weight: 500;
}#postnordTopbar > ul > li {
  display: flex;  flex-direction: row;  justify-content: center;  align-items: center;  height: 56px;  position: relative;
}#postnordTopbar ul li *:first-child {
  display: flex;  align-content: center;  align-items: center;
}#postnordTopbar .weak {
  color: rgba(0, 0, 0, 0.5);  font-size: 80%;
}#postnordTopbar .topbarlogo {
  display: flex;  align-items: center;  margin-left: 20px;
}#postnordTopbar .postnord-topbar-logo {
  width: 120px;  height: 23px;
}#postnordTopbar .dropdown {
  z-index: 200;
}#postnordTopbar .main-menu-dropdown .main-menu-dropdown-content a[target='_blank']::after {
  display: none;
}#postnordTopbar .dropdown-label {
  position: absolute;  font-size: 12px;  top: 12px;  left: 20px;  font-weight: 500;  color: #cdeefb;
}#postnordTopbar .dropdown-selected-value {
  font-size: 14px;  line-height: 14px;  padding-top: 15px;
}#postnordTopbar #languageBtn svg,#postnordTopbar #marketBtn svg {
  margin-top: 14px;
}#postnordTopbar a[target='_blank']::after {
  display: none;
}#postnordTopbar .logoUnderline {
  width: 150px;  height: 80%;  position: absolute;  top: 0;  border-bottom: 3px solid #fff;
}#postnordTopbar #mainMenuBtnHeader {
  display: flex;  justify-content: center;  align-items: center;
}#postnordTopbar .dropbtn {
  background-color: #005d92;  color: white;  padding: 16px;  font-weight: 500;  height: 24px;  border: none;  cursor: pointer;
}#postnordTopbar ul li .dropbtn {
  height: 34px;  padding: 0;  margin: 0px 20px;
}#postnordTopbar .angle-icon {
  margin-left: 8px;
}#postnordTopbar button[aria-expanded='true'] .angle-icon {
  transform: rotate(180deg);
}#postnordTopbar a[aria-expanded='true'] .angle-icon {
  transform: rotate(180deg);
}#postnordTopbar div[aria-expanded='true'] > .angle-icon {
  transform: rotate(180deg);
}#postnordTopbar .dropdown-icon {
  position: relative;  margin-left: 13px;
}#postnordTopbar .dropdown-icon[aria-hidden='true'] {
  display: none;
}#postnordTopbar .moreMenuText {
  margin: 0px;
}#postnordTopbar .main-menu-dropdown {
  position: relative;  align-items: center;  justify-content: center;
}#postnordTopbar .main-menu-dropdown-content {
  display: none;  position: absolute;  min-width: 14.5em;  width: 100%;  box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.2);  z-index: 9999;  margin: 0 !important;  top: 63px;  border-radius: 8px;  background: white;
}#postnordTopbar .main-menu-dropdown-content[aria-hidden='true'] {
  display: none;
}#postnordTopbar .main-menu-dropdown-content[aria-hidden='false'] {
  display: block;
}#postnordTopbar .main-menu-dropdown-content .main-menu-header {
  color: #000000;  font-weight: 700;  display: block;  font-size: 16px;  padding: 20px 0px 8px 20px;  letter-spacing: 0.4px;
}#postnordTopbar .main-menu-dropdown-content a {
  color: #1e1e1e;  white-space: nowrap;  display: block;
}#postnordTopbar .main-menu-dropdown-content a:first-child {
  padding-top: 20px;
}#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-name-container {
  height: 18px;  margin-bottom: 4px;  display: inline-block;  white-space: normal;  word-break: break-all;
}#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-name {
  display: inline;  line-height: 15px !important;  font-size: 15px;  font-weight: 500;  color: #005d92;
}#postnordTopbar .main-menu-dropdown-content .main-menu-dropdown-item-description {
  font-size: 13px;  color: #1e1e1e;  opacity: 0.7;  width: 200px;  white-space: normal;  text-overflow: clip;
}#postnordTopbar .show {
  display: block;
}#postnordTopbar .dropdown {
  box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.2);  border-bottom: 1px solid #f0f0f0;
}#postnordTopbar .dropdownWrapper .top-dropdown-container {
  display: block;  padding: 1em;
}#postnordTopbar .dropdownWrapper > .pn-divider {
  height: 0.6em;  width: 90%;  background: #03a0d6;  position: relative;  border-radius: 0 0.6em 0.6em 0;  padding: 0;
}#postnordTopbar .pn-divider:after {
  content: '';  width: 0.6em;  height: 0.6em;  border-radius: 50%;  position: absolute;  right: 0;  top: 0;  background: inherit;  transform: translateX(calc(100% + 0.2em));
}#postnordTopbar .dropdownWrapper .lower-btn-container {
  display: block;  padding: 1em 0;
}#postnordTopbar .dropdownWrapper .top-dropdown-container > .btnWrapper {
  padding: 16px 0 6px;
}#postnordTopbar .dropdownWrapper .lower-btn-container > div > button {
  background: none;  border: none;
}#postnordTopbar .dropdownWrapper .lower-btn-container a {
  background: none;
}#postnordTopbar ul li * .dropdownWrapper {
  font-weight: 500;  display: block;
}#postnordTopbar .dropdownWrapper a {
  border-bottom: 1px solid #f0f0f0;
}#postnordTopbar .dropdownWrapper a span {
  font-size: 15px;  padding: 16px 20px;
}#postnordTopbar #siteDropdown a {
  font-size: 15px;  padding: 16px 20px;
}#postnordTopbar .dropdownWrapper .btnWrapper {
  padding: 20px;  margin-left: auto;  margin-right: auto;  /* border-bottom: 1px solid #f0f0f0; */
}#postnordTopbar .dropdownWrapper a:last-child {
  border-bottom: none;
}#postnordTopbar .dropdownWrapper .accountBtn {
  background-color: #005d92;  transition: background 0.2s, box-shadow 0.1s;  color: #ffffff;  border-radius: 24px;  height: 44px;  width: 100%;  font-size: 15px;  cursor: pointer;  border: none;
}#postnordTopbar .dropdownWrapper .accountBtn:hover {
  background: #0d234b;
}#postnordTopbar .dropdownWrapper .accountBtn:focus {
  background: #0d234b;  box-shadow: 0 0 0 2px #fff, 0 0 0 4px #005d92;
}#postnordTopbar .dropdownWrapper .accountBtn .accountBtnText {
  margin-left: auto;  margin-right: auto;  font-size: 15px;
}#postnordTopbar .dropdownWrapper .loginBtn {
  color: #005d92;  border-bottom: none;  cursor: pointer;
}#postnordTopbar .dropdownWrapper .loginBtnMobile {
  width: 100%;
}#postnordTopbar .dropdownWrapper .loginBtn .loginBtnText {
  font-size: 15px;  display: block;  text-align: center;  padding: 5px 0;
}#postnordTopbar .dropdownWrapper .allNotifications {
  font-size: 15px;  color: #005d92;  text-align: center;  border-top: 1px solid #f0f0f0;
}#postnordTopbar .dropdownWrapper .allNotifications .allNotificationsText {
  display: block;
}#postnordTopbar .dropdownWrapper .border-bottom {
  border-bottom: 1px solid #f0f0f0;
}#postnordTopbar .main-menu-dropdown-content notifications,#postnordTopbar .main-menu-dropdown-content notifications * {
  white-space: normal !important;  line-height: 100% !important;
}#postnordTopbar .main-menu-dropdown-content notifications {
  max-height: 400px;  overflow-y: auto;  display: block;  padding: 0px;
}#postnordTopbar .right {
  right: 1px;
}#postnordTopbar .left {
  left: 1px;
}#postnordTopbar ul li * .notificationTextStyle {
  display: block;  color: #1e1e1e;  opacity: 0.7;  margin: 4px 0px;
}#postnordTopbar ul li * .notificationUnreadStyle {
  color: #005d92;  opacity: unset;
}#postnordTopbar ul li * .notificationItemStyle {
  display: block;  cursor: pointer;  margin: 0px 15px 0px 15px;  padding: 15px 0px 0px 0px;  overflow-y: hidden;
}#postnordTopbar .main-menu-dropdown-content a.notificationItemStyle:first-child {
  padding-top: 10px;
}#postnordTopbar ul li .notificationItemStyle :last-child {
  border-bottom: none;
}#postnordTopbar ul li * .notificationRichTextContainer {
  padding-top: 8px;  padding-bottom: 15px;  /* Scale rich text content */  zoom: 0.85;  transform: scale(0.85);
}#postnordTopbar ul li * .notificationRichTextContainer * {
  display: block;  margin: 0px;
}#postnordTopbar ul li * .notificationRichTextContainer p {
  padding: 0px;
}#postnordTopbar ul li * .notificationRichTextContainer * {
  /* Unset overrides to let humany pre-formatting prevail */  display: unset;  font-size: unset;  padding: unset;
}#postnordTopbar ul li * .notificationRichTextContainer p {
  /* Unset overrides to let humany pre-formatting prevail */  display: block;
}#postnordTopbar ul li * .notificationRichTextContainer a {
  background-color: transparent;
}#postnordTopbar .noNotifications {
  padding: 16px 20px;
}#postnordTopbar .dropdown-item {
  color: #005d92 !important;
}#postnordTopbar .selected {
  color: #bebebe !important;  pointer-events: none;
}#postnordTopbar .count-badge {
  background: #a70707;  position: absolute;  color: #fff;  text-align: center;  font-size: 12px !important;  top: 9px;  width: 16px;  height: 16px;  border-radius: 50%;  line-height: 16px !important;  text-overflow: ellipsis;  overflow: hidden;  margin-left: 11px;  display: inline-block !important;  z-index: 1;
}#postnordTopbar .hide {
  display: none !important;  height: 0px;  transition: height 0.5s linear;
}#postnordTopbar .main-menu-dropdown-content span.loginItems a {
  padding: 15px 20px 10px 20px;  display: block;
}#postnordTopbar .main-menu-dropdown-content span.loginItems a:first-child {
  border-top: 1px solid #f0f0f0;
}#postnordTopbar .main-menu-dropdown-content span.loginItems a div:first-child {
  display: inline;  color: #005d92;  font-size: 15px;
}#postnordTopbar .main-menu-dropdown-content span.loginItems a svg {
  vertical-align: middle;  margin-left: 4px;  height: 18px;  width: 18px;
}#postnordTopbar .pn-topbar-stage-tag-container {
  display: flex;  align-items: center;
}#postnordTopbar .pn-topbar-stage-tag {
  border-radius: 4px;  height: 32px;  width: 40px;  margin-left: 16px;  display: flex;  align-items: center;  justify-content: center;  font-size: 16px;  font-weight: 500;  background-color: #1e1e1e;
}#postnordTopbar .pn-topbar-stage-tag-mobile {
  margin-right: auto;
}/* Mobile view */@media screen and (min-width: 952px) {
  #postnordTopbar #mobile-menu {
    display: none;  
}  #postnordTopbar .pn-topbar-stage-tag-mobile {
    display: none;  
}
}@media screen and (max-width: 951px) {
  #postnordTopbar .left-items-wrapper {
    display: none !important;  
}  #postnordTopbar .desktopDesign {
    display: none !important;  
}  #postnordTopbar .pn-topbar-stage-tag-desktop {
    display: none;  
}  #postnordTopbar #mobile-menu {
    display: block;    width: 100%;  
}  #postnordTopbar .mobile-main-menu-dropdown-content[aria-hidden='false'] {
    box-shadow: 0 2048px 0 2048px rgba(255, 255, 255, 0.9);    margin-top: 56px;  
}  #postnordTopbar #mobile-menu .main-menu-dropdown {
    justify-content: flex-end;  
}  #postnordTopbar .mobile-main-menu-dropdown-content {
    display: none;    position: absolute;    z-index: 8;    width: 100%;    box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.2);    z-index: 9999;    margin: 0px 0px 0px 0px !important;    top: 56px;    background: white;  
}  #postnordTopbar .mobile-version {
    position: unset;    box-shadow: unset;  
}  #postnordTopbar .mobile-main-menu-dropdown-content[aria-hidden='true'] {
    display: none;  
}  #postnordTopbar .mobile-main-menu-dropdown-content[aria-hidden='false'] {
    display: block;  
}  #postnordTopbar .mobile-main-menu-dropdown-content a {
    color: #1e1e1e;    background-color: #ffffff;    white-space: nowrap;    display: block;    padding: 12px 23px;  
}  #postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper {
    width: 100%;    display: block;  
}  #postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div {
    width: 100%;    padding: 0px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section {
    display: flex;    align-content: center;    align-items: center;    border-top: 1px solid #f0f0f0;    min-height: 64px;    cursor: pointer;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobileLoginItemsContainer    div:first-child {
    padding-top: 10px;    border-top: 1px solid #f0f0f0;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobileLoginItemsContainer    div:last-child {
    padding-bottom: 10px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-dynamic-login-item {
    display: flex;    align-content: center;    align-items: center;    height: 45px;    cursor: pointer;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-dynamic-login-item    a    span {
    color: #1e1e1e;    align-content: center;    align-items: center;    padding: 0px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    a {
    width: 100%;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn {
    display: flex;    justify-content: center;    cursor: pointer;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn    .loginBtnMobileText {
    font-size: 15px;    padding: 0px;    cursor: pointer;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .mobileLoginBtn {
    color: #005d92;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    .mobil-menu-div-section    .loggedInUserBtnWrapper {
    display: inline-flex;    background-color: white;  
}  #topbarMobileLoggedOutDiv,  .mobil-menu-div-section .loggedInUserBtnWrapper,  #postnordTopbar #mobileMainMenuDropdown a:last-child {
    box-shadow: rgba(0, 0, 0, 0.16) 0px 20px 15px -20px;  
}  #postnordTopbar #mobileMainMenuDropdown a {
    background-color: #fff;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .userInformationWrapper {
    display: inline-block;  
}  #postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div a {
    border-bottom: none;    font-size: 15px;  
}  #postnordTopbar .mobile-main-menu-dropdown-content .dropdownWrapper .mobil-menu-div-section-wrapper div svg {
    margin-right: 28px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a {
    background-color: #f7f7f7;    font-size: 15px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a:first-child {
    padding-top: 24px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a    .grey-top-border {
    border-top: solid 1px lightgrey;    padding-top: 21px;  
}  #postnordTopbar    .mobile-main-menu-dropdown-content    .dropdownWrapper    .mobil-menu-div-section-wrapper    div    .mobile-version-under-menu    a    .correctMargins {
    margin-top: 0px;  
}  #postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu {
    color: #1e1e1e;    font-weight: 500;    display: inline-block;    font-size: 15px;    width: 100%;    background-color: #f0f0f0;  
}  #postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu main-menu {
    display: block;  
}  #postnordTopbar .main-menu-dropdown-content .mobile-version-under-menu main-menu a {
    background-color: #f7f7f7 !important;  
}  #postnordTopbar .mobileDivider {
    height: 20px;    width: 2px !important;    background: #f0f0f0;    margin: -6px 15px 0px 15px;  
}  #postnordTopbar .mobil-menu-div-section .badgeMobileVersion {
    position: unset;  
}
}@media screen and (max-width: 360px) {
  #postnordTopbar .pn-topbar-stage-tag-mobile {
    display: none;  
}  #postnordTopbar #topbarLogoMobile {
    margin-right: auto !important;  
}
}@keyframes spinner {
  100% {
    transform: rotate(360deg);  
}
}#pntopbar-outdated-browser-toaster {
  z-index: 999;  background-color: #fdefee !important;  border: 1px solid #a70707;  position: relative;  margin: 30px 30px auto 30px;  padding-top: 1em;  padding-bottom: 1.5em;  display: flex;  justify-content: space-between;  align-items: center;
}.pntopbar-toaster-txt-container {
  padding-top: 0.5em;  color: #000;  font-style: normal;  font-weight: normal;  font-size: 16px;  width: 100%;  white-space: normal;
}.toaster-triangle {
  border: none;  background: none;  margin-top: 10px;
}#postnordTopbar .toaster-close {
  background: none;  border: none;  cursor: pointer;  margin-top: 10px;
}#pn-notification-permission-overlay {
  position: fixed;  width: 100%;  height: 100%;  top: 0;  left: 0;  right: 0;  bottom: 0;  background-color: rgba(0, 0, 0, 0.5);  z-index: 99;
}#postnordTopbar #siteBtn {
  display: none;
}#topbarCartMobile {
  margin-left: 16px;
}#postnordTopbar #topbarLogoMobile {
  margin-left: 20px;
}#postnordTopbar .topbar-divider {
  border-right: 1px solid;  margin-left: 20px;  padding: 10px 0;  height: 25px;  align-self: center;
}#postnordTopbar #topbarMobileLoggedOutDiv .topbarMobileBtn,#postnordTopbar #topbarMobileLoggedInDiv .topbarMobileBtn {
  background-color: #005d92;  border-radius: 24px;  border: none;
}#postnordTopbar .loginBtnMobileText {
  color: #ffffff;
}#postnordTopbar #topbarMobileLogoutBtnDiv .loginBtnMobileText {
  color: #005d92;
}#postnordTopbar #topbarMobileLoggedInDiv,#postnordTopbar #topbarMobileLoggedOutDiv {
  display: flex;  justify-content: center;  flex-wrap: wrap;  align-items: center;  flex-direction: column;  padding: 16px 8px;
}#postnordTopbar #topbarMobileLoggedInDiv > *,#postnordTopbar #topbarMobileLoggedOutDiv > * {
  margin: 8px;
}#postnordTopbar .pn-topbar-selected-org-container,#postnordTopbar .pn-topbar-org-list {
  display: none;  flex-direction: column;  align-items: flex-start;  max-height: 22em;  overflow-y: auto;
}#postnordTopbar ul li .pn-topbar-org-list > button {
  background-color: Transparent;  background-repeat: no-repeat;  cursor: pointer;  border: none;  display: flex;  justify-content: space-between;  align-items: center;  flex-wrap: nowrap;  width: 100%;  padding: 0.5em 1em;  transition: background 0.15s ease-in-out;
}#postnordTopbar .pn-topbar-icon-loading svg {
  animation: rotate 1s infinite;  flex: 1 1 10em;
}#postnordTopbar .pn-topbar-icon-loading svg .circle {
  transform-origin: center center;  transform: rotate(-310deg);  stroke: #005d92;  stroke-linecap: round;  stroke-linejoin: round;  stroke-dasharray: 64;  animation: loading 2s infinite;
}#postnordTopbar .pn-topbar-icon-color-white svg .circle {
  stroke: #fff;
}#postnordTopbar .pn-topbar-icon-color-white {
  height: 23px;  width: 23px;  margin-left: 8px;
}#postnordTopbar .pn-topbar-icon-loading svg,#postnordTopbar .pn-topbar-icon-loading svg .circle {
  animation-timing-function: cubic-bezier(0.5, 0, 0.5, 1);
}@keyframes loading {
  0% {
    stroke-dashoffset: 55;  
}  50% {
    stroke-dashoffset: 12;  
}  100% {
    stroke-dashoffset: 55;  
}
}@keyframes rotate {
  from {
    transform: rotate(-180deg) scaleX(-1);  
}  to {
    transform: rotate(180deg) scaleX(-1);  
}
}.pn-topbar-org-list > button div svg {
  width: 1.5em;
}#postnordTopbar ul li .pn-topbar-org-list > button:hover,#postnordTopbar ul li .pn-topbar-org-list > button:focus {
  background: #f3f2f2;
}#postnordTopbar ul li .pn-topbar-org-list > button > * {
  display: block;  text-align: left;
}.pn-topbar-org-container-txt {
  margin-right: 1em;
}.pn-topbar-org-container-txt > * {
  margin: 0;
}#postnordTopbar .pn-topbar-selected-org-name {
  color: #000;  line-height: 1;  font-weight: 400;  white-space: normal;  margin: 1em 0 0;
}#postnordTopbar .pn-topbar-org-name {
  color: #005d92;  white-space: normal;  font-size: 16px;
}#postnordTopbar .pn-topbar-org-number,#postnordTopbar .pn-topbar-selected-org-number {
  color: #5e554a;  font-size: 12px;  margin: 0;  font-weight: 400;
}#postnordTopbar .mobil-menu-div-section-wrapper .mobil-menu-div-section .userInformationWrapper > div {
  padding: 0 24px;
}#postnordTopbar .mobil-menu-div-section-wrapper .mobil-menu-div-section .userInformationWrapper > .userInformationName {
  margin-top: 16px;
}#postnordTopbar  .mobil-menu-div-section-wrapper  .mobil-menu-div-section  .userInformationWrapper  > .pn-topbar-selected-org-container {
  margin-bottom: 16px;
}.hidden {
  display: none !important;
}/*---------------------------------------NOTIFICATION ALERTS-------------------------------------------*/#postnordTopbar .topbar-alerts-container {
  right: 0.5em;  min-width: 20em;
}/*---------------------------------------/NOTIFICATION ALERTS-------------------------------------------*//*---------------------------------------DISTURBANCE ALERTS-------------------------------------------*/.pn-disturbance-alert {
  display: flex;  justify-content: space-between;  align-items: center;  padding: 1em 3.5em 1em 1em;  flex-wrap: wrap;  background-color: #a70707;  color: #fff;
}.pn-disturbance-alert-right-wrapper {
  display: flex;  gap: 8px;  flex-wrap: wrap;
}.pn-disturbance-alert-right-wrapper > button {
  background: transparent;  outline: none;  border: none;  color: inherit;  min-width: 88px;
}.pn-disturbance-alert-left-wrapper {
  display: flex;  align-items: center;
}.pn-disturbance-alert-icon {
  margin-left: 16px;  margin-right: 16px;  flex-shrink: 0;
}.pn-disturbance-alert-left-wrapper > div {
  color: inherit;  text-decoration: none;
}.pn-disturbance-alert-left-wrapper h3,.pn-disturbance-alert-left-wrapper p {
  margin: 0;
}.pn-disturbance-alert-title {
  font-size: 16px;  line-height: 24px;  padding-left: 8px;
}.pn-disturbance-alert-message {
  color: #fff;  font-size: 14px;  line-height: 20px;  padding-left: 8px;
}/*---------------------------------------/DISTURBANCE ALERTS-------------------------------------------*//*---------------------------------------REMINDER ALERTS-------------------------------------------*/pn-topbar > div:first-of-type {
  position: relative;
}.pn-reminder-alert {
  display: flex;  justify-content: space-between;  align-items: center;  padding: 1em 3.25em 1em 1em;  flex-wrap: wrap;  background-color: #e0f8ff;  border: 1px solid #005d92;  box-shadow: 0 1.2px 3.6px rgba(0, 0, 0, 0.1), 0 6.4px 14.4px rgba(0, 0, 0, 0.13);  color: #000;  border-radius: 0.5em;  position: absolute;  gap: 0.5em;  z-index: 300;  transform: translateY(100%);  width: 40%;  max-width: 40em;  bottom: -1em;  right: 1em;
}.pn-reminder-alert,.pn-reminder-alert * {
  box-sizing: border-box;
}@media screen and (max-width: 880px) {
  .pn-reminder-alert {
    bottom: 0;    right: 0;    transform: translateY(0);    width: 100%;    max-width: 100%;    position: relative;  
}  .pn-reminder-alert-right-wrapper > button {
    flex: 1 1 45%;  
}
}.pn-reminder-alert-right-wrapper {
  display: flex;  gap: 0.5em;  flex-wrap: wrap;  flex: 1 1 auto;  margin-left: 2.5em;
}.pn-reminder-alert-right-wrapper > button {
  background: transparent;  outline: none;  border: none;  color: inherit;  min-width: 88px;
}.pn-reminder-close {
  padding: 0;  background: transparent;  height: 2em;  width: 2em;  margin: 0;  border: none;  outline: none;  transition: box-shadow 0.15s, background 0.15s;  border-radius: 50%;  cursor: pointer;  position: absolute;  right: 1em;  top: 1.8em;
}.pn-reminder-close:focus,.pn-reminder-close:hover {
  box-shadow: 0 0 0 2px #fff, 0 0 0 4px #005d92;  background: #e0f8ff;
}.pn-reminder-alert-left-wrapper {
  display: flex;  align-items: center;  flex: 999 1 35em;
}.pn-reminder-alert-icon {
  margin-right: 16px;  flex-shrink: 0;
}.pn-reminder-alert-left-wrapper > div {
  color: inherit;  text-decoration: none;
}.pn-reminder-alert-left-wrapper h3,.pn-reminder-alert-left-wrapper p {
  margin: 0;
}.pn-reminder-alert-title {
  font-size: 16px;  line-height: 24px;
}.pn-reminder-alert-message {
  font-size: 14px;  line-height: 20px;
}.pn-reminder-alert-link {
  color: #000;  text-decoration: none;
}/*---------------------------------------/REMINDER ALERTS-------------------------------------------*//*---------------------------------------ACCOUNT DROPDOWN-------------------------------------------*/#postnordTopbar #topbarMyPages,#postnordTopbar #topbarMyPages * {
  box-sizing: border-box;
}#postnordTopbar #topbarMyPages {
  width: max-content;  max-width: 20em;
}#postnordTopbar .dropdownWrapper .userInformationName,#postnordTopbar .dropdownWrapper .switchUserEmail {
  font-size: 16px;  color: #000000;  padding-bottom: 0;
}#postnordTopbar .dropdownWrapper .userInformationEmail {
  color: #5e554a;  font-size: 12px;  line-height: 1;  padding-top: 0;
}#postnordTopbar .dropdownWrapper .userInformationEmail,#postnordTopbar .dropdownWrapper .userInformationName,#postnordTopbar .dropdownWrapper .switchUserEmail {
  font-weight: 400;  white-space: normal;  word-break: break-all;
}/*---------------------------------------/ACCOUNT DROPDOWN-------------------------------------------*//*---------------------------------------NEW BUTTONS-------------------------------------------*//* Defaults/Dark */.topbar-button {
  border: none;  outline: none;  color: #fff;  transition: box-shadow 0.15s, background 0.15s, color 0.15s;  background: #005d92;  padding: 12px;  cursor: pointer;  border-radius: 36px;
}.topbar-button:focus {
  box-shadow: 0 0 0 2px #fff, 0 0 0 4px #005d92;
}/* /Defaults/Dark *//* Light */.topbar-button.topbar-button-light {
  color: #005d92;  background: #fff;  border: 1px solid #005d92;
}.topbar-button.topbar-button-light:hover,.topbar-button.topbar-button-light:focus {
  background: #e0f8ff;
}/* /Light *//* Warning */.topbar-button.topbar-button-warning-primary {
  color: #a70707;  background: #fdefee;  border: #fff;
}.topbar-button.topbar-button-warning-primary:hover,.topbar-button.topbar-button-warning-primary:focus {
  color: #fff;  background: #a70707;  border: 1px solid #fff;
}.topbar-button.topbar-button-warning-secondary {
  color: #fff;  border: 1px solid #fff;  background: #a70707;
}.topbar-button.topbar-button-warning-primary:focus,.topbar-button.topbar-button-warning-secondary:focus {
  box-shadow: 0 0 0 2px #a70707, 0 0 0 4px #fff;
}.topbar-button.topbar-button-warning-secondary:hover,.topbar-button.topbar-button-warning-secondary:focus {
  color: #a70707;  background: #fff;
}/* /Warning *//*---------------------------------------/NEW BUTTONS-------------------------------------------*/#postnordTopbar ul li .pn-topbar-selected-org-name-top-label {
  display: none;  max-width: calc(100% - 20px);  text-overflow: ellipsis;  overflow: hidden;  white-space: nowrap;
}#postnordTopbar .main-menu-dropdown-content .pn-topbar-logged-in,#postnordTopbar .main-menu-dropdown-content .pn-topbar-acting-as {
  padding: 1em;  padding-bottom: 0;
}#postnordTopbar .main-menu-dropdown-content .pn-topbar-login-status-container {
  padding-top: 0.7em;
}#postnordTopbar .pn-topbar-logout-btn {
  text-align: center;
}#postnordTopbar .pn-topbar-alerts-icon {
  width: 22px;  height: 22px;
}#postnordTopbar .market-selector-container {
  display: none;
}</style>
<div>
<!-- disturbance alert to be displayed above the topbar -->
<div class="pn-disturbance-alert hidden">  <div class="pn-disturbance-alert-left-wrapper">    <svg class="pn-disturbance-alert-icon" width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M23.6998 22L12.0003 0.940918L0.300781 22H23.6998ZM20.3008 20H3.69981L12.0003 5.05917L20.3008 20ZM11 14L10.7435 10.4095L12 8.14781L13.2565 10.4095L13 14H11ZM13.5 17C13.5 17.8276 12.8297 18.4987 12.0024 18.5H11.9976C11.1703 18.4987 10.5 17.8276 10.5 17C10.5 16.1716 11.1716 15.5 12 15.5C12.8284 15.5 13.5 16.1716 13.5 17Z" fill="white">
</path>    </svg>    <div>      <h3 class="pn-disturbance-alert-title">
</h3>      <p class="pn-disturbance-alert-message">
</p>    </div>  </div>  <div class="pn-disturbance-alert-right-wrapper">    <button class="pn-disturbance-alert-button pn-disturbance-alert-prev-button hidden topbar-button topbar-button-warning-secondary" data-xtranslate="PREVIOUS" aria-label="Forrige">Forrige</button>    <button class="pn-disturbance-alert-button pn-disturbance-alert-next-button hidden topbar-button topbar-button-warning-primary" data-xtranslate="NEXT" aria-label="Næste">Næste</button>  </div>
</div>
<div id="postnordTopbarContainer">  <div id="postnordTopbar">    <ul class="left-items-wrapper">      <a id="topbarLogo" href="#" tabindex="1" class="topbarlogo desktopDesign">        <svg class="postnord-topbar-logo focus-class-main" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="958.69" height="592.78998" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 600 114" enable-background="new 0 0 600 114" xml:space="preserve" tabindex="-1" style="height: 34px">          <g>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M0.5,23c8.159-0.027,16.317-0.026,24.476-0.11   c1.395-0.014,1.69,0.555,1.625,1.773c-0.076,1.408-0.018,2.824-0.018,4.321c0.306-0.057,0.597-0.022,0.742-0.151   c17.247-15.289,43.533-9.186,51.751,12.423c5.855,15.397,4.752,30.333-6.376,43.337c-11.739,13.717-34.058,14.373-45.195,5.514   c-0.173-0.138-0.425-0.176-1.005-0.404c0,8.232,0,16.264,0,24.297c-7.9,0-15.8-0.057-23.699,0.044   c-1.772,0.022-2.363-0.238-2.358-2.233C0.525,82.207,0.5,52.604,0.5,23z M25.926,58.078c-0.111,8.506,5.778,14.645,14.196,14.797   c8.028,0.145,14.247-5.814,14.377-13.776c0.149-9.208-5.378-15.385-13.883-15.515C32.008,43.452,26.041,49.34,25.926,58.078z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M600.5,94c-7.313-0.483-14.635-0.077-21.951-0.209   c-0.749-0.013-1.509-0.079-2.246,0.016c-1.623,0.209-2.021-0.555-1.909-2.022c0.106-1.39,0.022-2.795,0.022-4.542   c-1.484,1.232-2.677,2.336-3.98,3.287c-12.225,8.908-31.617,6.816-41.996-4.505c-12.975-14.155-12.913-39.895-0.158-54.186   c11.564-12.955,33.688-14.569,45.262-5.357c0.167,0.133,0.427,0.149,0.873,0.296c0-6.274,0.096-12.406-0.057-18.531   c-0.046-1.872,0.67-2.394,2.293-2.696c6.945-1.293,13.872-2.685,20.807-4.037c0.398-0.078,0.84-0.046,1.041-0.515   c1.711-0.378,2.053,0.288,2.049,2C600.481,33.333,600.5,63.666,600.5,94z M546.501,58.162c-0.007,8.704,5.763,14.765,14.097,14.809   c8.521,0.047,14.443-5.975,14.477-14.719c0.031-8.51-5.903-14.465-14.411-14.461C552.249,43.795,546.507,49.622,546.501,58.162z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M418.68,20.469c7.956,0.122,14.641,1.237,21.007,3.964   c14.999,6.423,22.888,20.112,21.583,36.413c-1.56,19.49-14.82,30.803-32.305,34.098c-10.387,1.959-20.588,1.152-30.359-3.009   c-15.441-6.573-22.246-19.692-21.436-35.479c1.156-22.514,17.57-33.092,35.115-35.436C414.754,20.69,417.254,20.588,418.68,20.469z    M404.795,58.289c0.002,8.482,6.156,14.709,14.416,14.588c8.381-0.123,14.197-6.057,14.205-14.492   c0.008-8.794-5.865-14.836-14.389-14.802C410.632,43.617,404.791,49.65,404.795,58.289z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M129.176,20.482c10.908,0.271,21.103,2.735,29.691,9.914   c7.15,5.977,10.82,13.792,11.622,22.978c0.916,10.492-1.016,20.253-8.051,28.488c-6.028,7.055-13.9,10.938-22.862,12.817   c-10.625,2.228-21.037,1.558-31.112-2.567c-16.718-6.844-23.339-21.486-21.72-37.907c1.813-18.375,14.729-29.348,31.757-32.67   C122.021,20.848,125.578,20.472,129.176,20.482z M128.742,43.584c-8.521-0.068-14.478,5.886-14.648,14.643   c-0.16,8.229,6.154,14.627,14.443,14.633c8.247,0.006,14.273-6.037,14.366-14.404C142.997,49.93,137.017,43.65,128.742,43.584z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M324.639,28.651c8.594-8.386,18.7-9.742,29.544-6.832   c9.833,2.639,14.446,10.021,16.273,19.528c0.489,2.543,0.64,5.113,0.637,7.703c-0.019,14.081-0.042,28.161,0.029,42.241   c0.01,1.875-0.365,2.59-2.431,2.553c-7.162-0.133-14.33-0.115-21.493-0.008c-1.939,0.029-2.548-0.473-2.538-2.49   c0.053-11.744-0.033-23.49-0.104-35.235c-0.007-1.157-0.137-2.329-0.354-3.466c-1.214-6.333-3.75-8.44-9.795-8.213   c-5.817,0.218-9.371,3.372-9.884,9.181c-0.579,6.562-0.163,13.155-0.221,19.734c-0.054,6.081-0.073,12.164,0.026,18.244   c0.029,1.776-0.547,2.259-2.273,2.238c-7.331-0.083-14.664-0.077-21.995-0.002c-1.607,0.016-2.106-0.403-2.102-2.082   c0.058-22.246,0.063-44.491-0.005-66.735c-0.005-1.857,0.645-2.147,2.286-2.129c7.165,0.082,14.332,0.114,21.494-0.014   c2.094-0.038,2.843,0.564,2.594,2.642C324.215,26.448,324.074,27.473,324.639,28.651z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M211.215,20.546c8.705,0.298,16.646,0.971,24.469,2.806   c1.644,0.386,1.959,0.893,1.548,2.508c-1.332,5.236-2.582,10.498-3.658,15.792c-0.402,1.981-1.126,2.04-2.841,1.527   c-8.105-2.422-16.334-3.978-24.853-2.736c-0.653,0.095-1.295,0.284-1.93,0.472c-1.563,0.46-2.785,1.376-2.767,3.105   c0.019,1.79,1.407,2.568,2.948,2.917c5.601,1.269,11.371,1.593,16.944,3.038c2.986,0.774,5.918,1.682,8.708,3.009   c7.723,3.672,11.162,9.681,10.907,18.218c-0.302,10.111-5.477,16.606-14.466,20.478c-7.246,3.119-14.946,3.904-22.702,4.075   c-9.706,0.214-19.249-1.075-28.61-3.718c-1.525-0.431-1.939-0.91-1.485-2.545c1.534-5.527,2.936-11.093,4.245-16.678   c0.423-1.804,1.067-1.934,2.69-1.309c8.626,3.319,17.51,5.265,26.834,4.569c1.261-0.095,2.486-0.319,3.63-0.831   c1.287-0.574,2.195-1.458,2.18-3.033c-0.015-1.588-0.941-2.426-2.275-2.937c-2.905-1.114-5.99-1.359-9.034-1.76   c-5.292-0.696-10.524-1.649-15.497-3.649c-14.374-5.781-17.364-24.28-5.58-34.483c6.473-5.604,14.377-7.417,22.58-8.323   C206.092,20.74,209.012,20.681,211.215,20.546z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M245.499,50.268c0-13.667,0.042-27.333-0.047-41   c-0.013-1.896,0.495-2.345,2.345-2.316c7.248,0.112,14.501,0.127,21.748-0.007c1.991-0.037,2.341,0.654,2.285,2.421   c-0.121,3.83,0.048,7.668-0.075,11.498c-0.056,1.717,0.579,2.098,2.161,2.081c6.583-0.072,13.167,0.01,19.75-0.057   c1.734-0.018,2.28,0.252,1.311,2.007c-3.419,6.189-6.769,12.417-10.077,18.667c-0.596,1.125-1.319,1.502-2.556,1.464   c-2.748-0.084-5.507,0.099-8.247-0.068c-1.89-0.115-2.359,0.479-2.349,2.35c0.081,14.416,0.045,28.833,0.044,43.25   c0,3.23-0.001,3.231-3.204,3.232c-6.833,0-13.668-0.084-20.499,0.051c-2.051,0.041-2.656-0.46-2.641-2.574   C245.546,77.602,245.499,63.935,245.499,50.268z">
</path>            <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M493.583,30.506c5.988-8.059,13.937-9.128,22.504-8.469   c1.558,0.119,2.31,0.717,2.241,2.489c-0.261,6.734-0.4,13.473-0.518,20.211c-0.027,1.597-0.529,2.004-2.111,1.595   c-2.996-0.774-6.07-1.013-9.166-0.75c-8.641,0.735-12.903,5.295-12.938,13.97c-0.043,10.494-0.067,20.988,0.035,31.48   c0.021,2.093-0.354,2.877-2.683,2.82c-7.074-0.174-14.156-0.104-21.234-0.033c-1.608,0.016-2.344-0.229-2.338-2.125   c0.066-22.236,0.058-44.473,0.01-66.708c-0.004-1.605,0.406-2.127,2.068-2.108c7.41,0.086,14.824,0.084,22.234,0.001   c1.592-0.019,2.025,0.507,1.922,1.999C493.494,26.526,493.583,28.188,493.583,30.506z">
</path>          </g>        </svg>      </a>      <li class="topbar-divider">
</li>      <li class="desktopDesign">        <div id="topbarMainMenu" class="main-menu-dropdown" role="topbarMainMenu">          <button onclick="pnTopbar.showMenu(event, this);" class="dropbtn" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false" tabindex="17" role="tooltip" name="sites">            <span tabindex="-1" id="pn-sites-txt" data-xtranslate="Portal" aria-label="Portal" style="display: flex;">Portal</span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16">
</rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="mainMenuDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="sites" aria-label="Hjemmesider">Hjemmesider</div>            <main-menu>
<a href="https://www.postnord.dk" tabindex="18" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="postnord.dk" aria-label="postnord.dk">postnord.dk</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD" aria-label="Information om PostNord">Information om PostNord</div>
</div>
</a>
<a href="https://portal.postnord.com/" tabindex="19" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="CUSTOMER_PORTAL" style="color:#bebebe" aria-label="Kundeportal">Kundeportal</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="MANAGE_YOUR_SHIPMENTS" aria-label="Håndtere dine forsendelser">Håndtere dine forsendelser</div>
</div>
</a>
<a href="https://www.postnord.com" tabindex="20" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="postnord.com" aria-label="postnord.com">postnord.com</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD_GROUP" aria-label="Information om PostNord Group">Information om PostNord Group</div>
</div>
</a>
</main-menu>          </div>        </div>      </li>      <!-- Site selector for postnord.com -->      <li data-name="topbarSites" class="desktopDesign">        <div class="main-menu-dropdown">       
       <button id="siteBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" role="tooltip" name="SITE" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="SITE" aria-label="Side">Side</span>            <span class="dropdown-selected-value" tabindex="-1" data-xtranslate="PN_GROUP" aria-label="PostNord Koncernen">PostNord Koncernen</span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16">
</rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="siteDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div>
</div>            <div class="dropdownWrapper" role="siteSelector">              <a class="dropdown-item" href="https://portal.postnord.com" data-xtranslate="PN_PORTAL" aria-label="PostNord Portal">PostNord Portal</a>              <a class="dropdown-item" href="https://www.postnord.dk/en" data-xtranslate="PN_DA" aria-label="PostNord Danmark">PostNord Danmark</a>              <a class="dropdown-item" href="https://www.postnord.fi/en" data-xtranslate="PN_FI" aria-label="PostNord Finland">PostNord Finland</a>              <a class="dropdown-item" href="https://www.postnord.no/en" data-xtranslate="PN_NO" aria-label="PostNord Norge">PostNord Norge</a>              <a class="dropdown-item" href="https://www.postnord.se/en" data-xtranslate="PN_SV" aria-label="PostNord Sverige">PostNord Sverige</a>              <a class="dropdown-item" href="https://www.postnord.com/en/about-us/our-market/germany" data-xtranslate="PN_DE" aria-label="PostNord Tyskland">PostNord Tyskland</a>              <a class="dropdown-item" href="https://www.stralfors.com" data-xtranslate="PN_STRALFORS" aria-label="PostNord Strålfors">PostNord Strålfors</a>              <a class="dropdown-item" href="https://www.directlink.com" data-xtranslate="DIRECT_LINK" aria-label="Direct Link">Direct Link</a>            </div>          </div>        </div>      </li>    </ul>    <ul>      <li id="topbarLogin" class="desktopDesign" role="topbarLogin" style="display: flex;">        <div class="main-menu-dropdown">                    <div class="main-menu-dropdown-content left" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="CUSTOMER_PORTAL" aria-label="Kundeportal">Kundeportal</div>            <div class="dropdownWrapper">              <div class="btnWrapper">                <button class="accountBtn" onclick="pnTopbar.login()" tabindex="3">                  <span class="accountBtnText" data-xtranslate="login" tabindex="-1" aria-label="Log ind">Log ind</span>                </button>              </div>              <a onclick="pnTopbar.createNewUser()" class="loginBtn" tabindex="4">                <span data-xtranslate="CREATE_NEW_ACCOUNT" class="loginBtnText focus-class-links" tabindex="-1" aria-label="Opret ny konto">Opret ny konto</span>              </a>              <span class="loginItems" role="loginItems">                <!-- Will be filled with dynamic login items if any -->              </span>            </div>          </div>        </div>      </li>      <!-- New design on Logged in user -->      <li id="topbarUser" class="desktopDesign" role="topbarUser" style="display: none;">        <div class="main-menu-dropdown">          <button id="openLoggedInMenu" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="2" aria-expanded="false">            <span class="dropdown-label pn-topbar-selected-org-name-top-label">
</span>            <span class="dropdown-label pn-topbar-user-label" data-xtranslate="USER" aria-label="Bruger">Bruger</span>            <span id="loggedInUserName" class="dropdown-selected-value ellipsis" tabindex="-1">User</span>            <svg class="angle-icon" width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">              <g id="icons-/-16x16-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                <g id="angle-small-down">                  <rect id="Bound" opacity="0.290969122" x="0" y="0" width="16" height="16">
</rect>                  <polygon id="Combined-Shape" fill="#FFFFFF" transform="translate(7.999744, 8.666667) scale(1, -1) rotate(-270.000000) translate(-7.999744, -8.666667) " points="8.91641099 4.00025568 10.666411 4.00025568 10.666411 4.66771307 7.99974432 8.66771307 10.666411 12.6677131 10.666411 13.3330777 8.91641099 13.3330777 5.33307766 8.66666667">                  </polygon>                </g>              </g>            </svg>          </button>          <div id="topbarMyPages" class="main-menu-dropdown-content left" aria-hidden="true">            <div class="dropdownWrapper">              <div class="main-menu-header pn-topbar-acting-as hidden" data-xtranslate="ACTING_AS" aria-label="Fungerer som">Fungerer som</div>              <div class="top-dropdown-container pn-topbar-login-status-container pn-topbar-acting-as-container hidden">                <div class="switchUserEmail" role="switchUserEmail">
</div>              </div>              <div class="main-menu-header pn-topbar-logged-in" data-xtranslate="LOGGED_IN_AS" aria-label="Logget ind som">Logget ind som</div>              <div class="top-dropdown-container pn-topbar-login-status-container">                <div class="userInformationName">
</div>                <div class="userInformationEmail" role="userInformationEmail">
</div>                <div class="pn-topbar-selected-org-container">                  <p class="pn-topbar-selected-org-name">
</p>                  <p class="pn-topbar-selected-org-number">
</p>                </div>                <div class="btnWrapper topbarMyAccountBtn" id="topbarOpenMyAccountBtn">                  <button class="accountBtn" onclick="pnTopbar.openMyAccount()" tabindex="3">                    <span class="accountBtnText focus-class-links" tabindex="-1" data-xtranslate="MY_ACCOUNT" aria-label="Min konto">Min konto</span>                  </button>                </div>                <div class="btnWrapper switchUserFullAccessContainer hidden">                  <button class="accountBtn switchUserFullAccessBtn">                    <div class="accountBtnText switchUserFullAccessBtnText focus-class-links" tabindex="-1">                      <span data-xtranslate="REQUEST_FULL_ACCESS" aria-label="Anmod om fuld adgang">Anmod om fuld adgang</span>                      <div>
</div>                    </div>                  </button>                </div>              </div>              <span class="loginItems" role="loginItems">                <!-- Will be filled with dynamic login items if any -->              </span>              <div class="pn-divider">
</div>              <div class="lower-btn-container">                <div class="pn-topbar-org-list">
</div>                <a onclick="pnTopbar.logout()" class="loginBtn pn-topbar-logout-btn" tabindex="5">                  <span data-xtranslate="LOGOUT" class="loginBtnText focus-class-links" tabindex="-1" aria-label="Log ud">Log ud</span>                </a>              </div>            </div>          </div>        </div>      </li>      <!-- New design of Market -->      <li data-name="topbarMarkets" class="desktopDesign market-selector-container" style="display: flex;">        <div class="main-menu-dropdown">          <button id="marketBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="6" role="tooltip" name="COUNTRY" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="COUNTRY" aria-label="Land">Land</span>            <span class="dropdown-selected-value" id="marketText" tabindex="-1">Danmark</span>                      </button>          <div id="marketDropdown" class="main-menu-dropdown-content left" aria-hidden="true">            <div>
</div>            <div class="dropdownWrapper" role="marketSelector">
<a onclick="pnTopbar.changeMarkets(event,&quot;se&quot;);" class="dropdown-item" href="https://www.postnord.se" role="SE" id="SE" tabindex="7" data-value="SE" style="padding: 0px;">
<span data-xtranslate="SWEDEN" class="focus-class-links" tabindex="-1" aria-label="Sverige">Sverige</span>
</a>
<a onclick="pnTopbar.changeMarkets(event,&quot;dk&quot;);" class="dropdown-item selected" style="color:#005D92; padding: 0px;" "="" href="https://www.postnord.dk" role="DK" id="DK" tabindex="8" data-value="DK">
<span data-xtranslate="DENMARK" class="focus-class-links" tabindex="-1" aria-label="Danmark">Danmark</span>
</a>
</div>          </div>        </div>      </li>      <!-- New design of language -->      <li data-name="topbarLanguages" class="desktopDesign">        <div class="main-menu-dropdown">          <button id="languageBtn" onclick="pnTopbar.showMenu(event, this);" class="dropbtn" tabindex="11" role="tooltip" name="LANGUAGE" aria-expanded="false">            <span class="dropdown-label" data-xtranslate="LANGUAGE" aria-label="Sprog">Sprog</span>            <span class="dropdown-selected-value" id="languageText" tabindex="-1">Dansk</span>                      </button>          <div class="main-menu-dropdown-content right" id="languageDropdown" aria-hidden="true">            <div>
</div>            <div class="dropdownWrapper" role="langageSelector">
<a class="dropdown-item selected" onclick="pnTopbar.changeLanguage(event,&quot;da&quot;);" data-value="da" href="#/da" tabindex="12" style="padding: 0px;">
<span class="focus-class-links" tabindex="-1">Dansk</span>
</a>
<a class="dropdown-item" onclick="pnTopbar.changeLanguage(event,&quot;en&quot;);" data-value="en" href="#/en" tabindex="13" style="padding: 0px;">
<span class="focus-class-links" tabindex="-1">English</span>
</a>
</div>          </div>        </div>      </li>      <!-- New design of notifications -->      <li id="topbarAlerts" class="desktopDesign" role="alertsElements">        <div class="main-menu-dropdown">          <button type="button" onclick="pnTopbar.showMenu(event, this);" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false" id="topbarAlertsMenu" tabindex="41" class="dropbtn" role="tooltip" name="notifications">            <span aria-label="number of alerts" class="count-badge" title="1">1</span>            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 18" tabindex="-1" class="pn-topbar-alerts-icon">              <title data-xtranslate="notifications" aria-label="Notifikationer">Notifikationer</title>              <path fill-rule="evenodd" clip-rule="evenodd" d="M2 6a6 6 0 1 1 12 0v1.586l.536.535A5 5 0 0 1 16 11.657V12a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-.343A5 5 0 0 1 1.464 8.12L2 7.586V6Zm6-4a4 4 0 0 0-4 4v2a1 1 0 0 1-.293.707l-.828.829A3 3 0 0 0 2.073 11h11.854a3 3 0 0 0-.806-1.464l-.828-.829A1 1 0 0 1 12 8V6a4 4 0 0 0-4-4ZM4.684 14.051a1 1 0 0 1 1.265.633C6.257 15.608 7.222 16 8 16c.778 0 1.743-.392 2.051-1.316a1 1 0 0 1 1.898.632C11.257 17.392 9.222 18 8 18s-3.257-.608-3.949-2.684a1 1 0 0 1 .633-1.265Z" fill="#fff">
</path>            </svg>          </button>          <div class="main-menu-dropdown-content topbar-alerts-container" aria-hidden="true">            <div class="main-menu-header" data-xtranslate="notifications" aria-label="Notifikationer">
<font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">Notifications</font>
</font>
</div>            <div class="dropdownWrapper">              <unread-notifications class="hide">                <div class="weak noNotifications" data-xtranslate="0_UNREAD_NOTIFICATIONS" aria-label="0 ulæste notifikationer">
<font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">0 unread notifications</font>
</font>
</div>              </unread-notifications>              <notifications class="">
<a class="notificationItemStyle">
<p class="notificationTextStyle notificationUnreadStyle" style="font-size: 14px;">
<font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">Problems with push notifications on complaints</font>
</font>
</p>
<p class="notificationTextStyle notificationUnreadStyle" style="font-size: 12px;">2022-11-09<span style="min-width:6px; padding:0px; display: inline-block;">
</span>08:51</p>
<div class="notificationRichTextContainer">
<font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">We are currently experiencing problems with pushing out notifications on ongoing complaints. </font>
<font style="vertical-align: inherit;">We are working on correcting the error.</font>
</font>
</div>
</a>
<a class="notificationItemStyle">
<p class="notificationTextStyle" style="font-size: 14px;">
<font style="vertical-align: inherit;">
<font style="vertical-align: inherit;">Danish VAT and customs duties</font>
</font>
</p>
<p class="notificationTextStyle" style="font-size: 12px;">2021-12-13<span style="min-width:6px; padding:0px; display: inline-block;">
</span>05:57</p>
<div class="notificationRichTextContainer">Grundet vedligeholdelse er det ikke muligt at betale told fakturaer mellem 12:30 - 13:30 i dag, 13 december.</div>
</a>
</notifications>              <a id="topbarAlertsNavigation" href="https://portal.postnord.com/pnalerts/" class="allNotifications" tabindex="42">                <span data-xtranslate="ALL_NOTIFICATIONS" class="focus-class-links allNotificationsText" tabindex="-1" aria-label="Alle notifikationer">Alle notifikationer</span>              </a>            </div>          </div>        </div>      </li>      <!-- New design on Cart -->      <li class="desktopDesign">        <div class="main-menu-dropdown" style="display: none;">          <a id="topbarCart" role="topbarCart" tabindex="44" class="dropbtn" href="https://portal.postnord.com/skickadirekt/payment" style="display: none;">            <span class="hide count-badge" title="">
</span>            <svg xmlns="http://www.w3.org/2000/svg" width="23" height="22" viewBox="0 0 23 22" class="focus-class-main" tabindex="-1">              <title data-xtranslate="CART" aria-label="Varekurv">Varekurv</title>              <path fill="#FFF" fill-rule="evenodd" d="M19.318 17.217c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.367 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm-9.907 0c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.368 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm13.375-4.646v-8.38H5.944L4.34 0H0v2.095h3.255l2.69 10.34c-.496.478-.992.956-.992 1.913 0 .956.991 1.913 1.982 1.913.04.005 15.85 0 15.85 0v-1.913H7.43c-.248 0-.495-.24-.495-.478 0-.24.247-.479.495-.479l15.356-.82z">
</path>            </svg>          </a>        </div>      </li>      <!-- New mobile design.  -->      <li id="mobile-menu">        <div id="mobileTopbarMainMenu" class="main-menu-dropdown" role="topbarMainMenu">          <!-- Postnord logo for mobile  -->          <a id="topbarLogoMobile" class="topbarlogo" href="#" tabindex="1" style="margin-right: auto;">            <svg class="postnord-topbar-logo focus-class-main" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="958.69" height="592.78998" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 600 114" enable-background="new 0 0 600 114" xml:space="preserve" tabindex="-1" style="height: 34px">              <g>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M0.5,23c8.159-0.027,16.317-0.026,24.476-0.11   c1.395-0.014,1.69,0.555,1.625,1.773c-0.076,1.408-0.018,2.824-0.018,4.321c0.306-0.057,0.597-0.022,0.742-0.151   c17.247-15.289,43.533-9.186,51.751,12.423c5.855,15.397,4.752,30.333-6.376,43.337c-11.739,13.717-34.058,14.373-45.195,5.514   c-0.173-0.138-0.425-0.176-1.005-0.404c0,8.232,0,16.264,0,24.297c-7.9,0-15.8-0.057-23.699,0.044   c-1.772,0.022-2.363-0.238-2.358-2.233C0.525,82.207,0.5,52.604,0.5,23z M25.926,58.078c-0.111,8.506,5.778,14.645,14.196,14.797   c8.028,0.145,14.247-5.814,14.377-13.776c0.149-9.208-5.378-15.385-13.883-15.515C32.008,43.452,26.041,49.34,25.926,58.078z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M600.5,94c-7.313-0.483-14.635-0.077-21.951-0.209   c-0.749-0.013-1.509-0.079-2.246,0.016c-1.623,0.209-2.021-0.555-1.909-2.022c0.106-1.39,0.022-2.795,0.022-4.542   c-1.484,1.232-2.677,2.336-3.98,3.287c-12.225,8.908-31.617,6.816-41.996-4.505c-12.975-14.155-12.913-39.895-0.158-54.186   c11.564-12.955,33.688-14.569,45.262-5.357c0.167,0.133,0.427,0.149,0.873,0.296c0-6.274,0.096-12.406-0.057-18.531   c-0.046-1.872,0.67-2.394,2.293-2.696c6.945-1.293,13.872-2.685,20.807-4.037c0.398-0.078,0.84-0.046,1.041-0.515   c1.711-0.378,2.053,0.288,2.049,2C600.481,33.333,600.5,63.666,600.5,94z M546.501,58.162c-0.007,8.704,5.763,14.765,14.097,14.809   c8.521,0.047,14.443-5.975,14.477-14.719c0.031-8.51-5.903-14.465-14.411-14.461C552.249,43.795,546.507,49.622,546.501,58.162z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M418.68,20.469c7.956,0.122,14.641,1.237,21.007,3.964   c14.999,6.423,22.888,20.112,21.583,36.413c-1.56,19.49-14.82,30.803-32.305,34.098c-10.387,1.959-20.588,1.152-30.359-3.009   c-15.441-6.573-22.246-19.692-21.436-35.479c1.156-22.514,17.57-33.092,35.115-35.436C414.754,20.69,417.254,20.588,418.68,20.469z    M404.795,58.289c0.002,8.482,6.156,14.709,14.416,14.588c8.381-0.123,14.197-6.057,14.205-14.492   c0.008-8.794-5.865-14.836-14.389-14.802C410.632,43.617,404.791,49.65,404.795,58.289z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M129.176,20.482c10.908,0.271,21.103,2.735,29.691,9.914   c7.15,5.977,10.82,13.792,11.622,22.978c0.916,10.492-1.016,20.253-8.051,28.488c-6.028,7.055-13.9,10.938-22.862,12.817   c-10.625,2.228-21.037,1.558-31.112-2.567c-16.718-6.844-23.339-21.486-21.72-37.907c1.813-18.375,14.729-29.348,31.757-32.67   C122.021,20.848,125.578,20.472,129.176,20.482z M128.742,43.584c-8.521-0.068-14.478,5.886-14.648,14.643   c-0.16,8.229,6.154,14.627,14.443,14.633c8.247,0.006,14.273-6.037,14.366-14.404C142.997,49.93,137.017,43.65,128.742,43.584z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M324.639,28.651c8.594-8.386,18.7-9.742,29.544-6.832   c9.833,2.639,14.446,10.021,16.273,19.528c0.489,2.543,0.64,5.113,0.637,7.703c-0.019,14.081-0.042,28.161,0.029,42.241   c0.01,1.875-0.365,2.59-2.431,2.553c-7.162-0.133-14.33-0.115-21.493-0.008c-1.939,0.029-2.548-0.473-2.538-2.49   c0.053-11.744-0.033-23.49-0.104-35.235c-0.007-1.157-0.137-2.329-0.354-3.466c-1.214-6.333-3.75-8.44-9.795-8.213   c-5.817,0.218-9.371,3.372-9.884,9.181c-0.579,6.562-0.163,13.155-0.221,19.734c-0.054,6.081-0.073,12.164,0.026,18.244   c0.029,1.776-0.547,2.259-2.273,2.238c-7.331-0.083-14.664-0.077-21.995-0.002c-1.607,0.016-2.106-0.403-2.102-2.082   c0.058-22.246,0.063-44.491-0.005-66.735c-0.005-1.857,0.645-2.147,2.286-2.129c7.165,0.082,14.332,0.114,21.494-0.014   c2.094-0.038,2.843,0.564,2.594,2.642C324.215,26.448,324.074,27.473,324.639,28.651z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M211.215,20.546c8.705,0.298,16.646,0.971,24.469,2.806   c1.644,0.386,1.959,0.893,1.548,2.508c-1.332,5.236-2.582,10.498-3.658,15.792c-0.402,1.981-1.126,2.04-2.841,1.527   c-8.105-2.422-16.334-3.978-24.853-2.736c-0.653,0.095-1.295,0.284-1.93,0.472c-1.563,0.46-2.785,1.376-2.767,3.105   c0.019,1.79,1.407,2.568,2.948,2.917c5.601,1.269,11.371,1.593,16.944,3.038c2.986,0.774,5.918,1.682,8.708,3.009   c7.723,3.672,11.162,9.681,10.907,18.218c-0.302,10.111-5.477,16.606-14.466,20.478c-7.246,3.119-14.946,3.904-22.702,4.075   c-9.706,0.214-19.249-1.075-28.61-3.718c-1.525-0.431-1.939-0.91-1.485-2.545c1.534-5.527,2.936-11.093,4.245-16.678   c0.423-1.804,1.067-1.934,2.69-1.309c8.626,3.319,17.51,5.265,26.834,4.569c1.261-0.095,2.486-0.319,3.63-0.831   c1.287-0.574,2.195-1.458,2.18-3.033c-0.015-1.588-0.941-2.426-2.275-2.937c-2.905-1.114-5.99-1.359-9.034-1.76   c-5.292-0.696-10.524-1.649-15.497-3.649c-14.374-5.781-17.364-24.28-5.58-34.483c6.473-5.604,14.377-7.417,22.58-8.323   C206.092,20.74,209.012,20.681,211.215,20.546z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M245.499,50.268c0-13.667,0.042-27.333-0.047-41   c-0.013-1.896,0.495-2.345,2.345-2.316c7.248,0.112,14.501,0.127,21.748-0.007c1.991-0.037,2.341,0.654,2.285,2.421   c-0.121,3.83,0.048,7.668-0.075,11.498c-0.056,1.717,0.579,2.098,2.161,2.081c6.583-0.072,13.167,0.01,19.75-0.057   c1.734-0.018,2.28,0.252,1.311,2.007c-3.419,6.189-6.769,12.417-10.077,18.667c-0.596,1.125-1.319,1.502-2.556,1.464   c-2.748-0.084-5.507,0.099-8.247-0.068c-1.89-0.115-2.359,0.479-2.349,2.35c0.081,14.416,0.045,28.833,0.044,43.25   c0,3.23-0.001,3.231-3.204,3.232c-6.833,0-13.668-0.084-20.499,0.051c-2.051,0.041-2.656-0.46-2.641-2.574   C245.546,77.602,245.499,63.935,245.499,50.268z">
</path>                <path fill-rule="evenodd" clip-rule="evenodd" fill="#FFFFFF" d="M493.583,30.506c5.988-8.059,13.937-9.128,22.504-8.469   c1.558,0.119,2.31,0.717,2.241,2.489c-0.261,6.734-0.4,13.473-0.518,20.211c-0.027,1.597-0.529,2.004-2.111,1.595   c-2.996-0.774-6.07-1.013-9.166-0.75c-8.641,0.735-12.903,5.295-12.938,13.97c-0.043,10.494-0.067,20.988,0.035,31.48   c0.021,2.093-0.354,2.877-2.683,2.82c-7.074-0.174-14.156-0.104-21.234-0.033c-1.608,0.016-2.344-0.229-2.338-2.125   c0.066-22.236,0.058-44.473,0.01-66.708c-0.004-1.605,0.406-2.127,2.068-2.108c7.41,0.086,14.824,0.084,22.234,0.001   c1.592-0.019,2.025,0.507,1.922,1.999C493.494,26.526,493.583,28.188,493.583,30.506z">
</path>              </g>            </svg>          </a>          <!-- Mobile design on Cart -->          <div class="main-menu-dropdown" style="display: none;">            <a id="topbarCartMobile" role="topbarCart" href="https://portal.postnord.com/skickadirekt/payment" style="display: none;">              <span class="hide count-badge" style="top: -6px" title="">
</span>              <svg xmlns="http://www.w3.org/2000/svg" width="23" height="22" viewBox="0 0 23 22">                <title data-xtranslate="CART" aria-label="Varekurv">Varekurv</title>                <path fill="#FFF" fill-rule="evenodd" d="M19.318 17.217c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.367 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm-9.907 0c-1.367 0-2.476 1.072-2.476 2.392 0 1.32 1.11 2.391 2.476 2.391 1.368 0 2.477-1.071 2.477-2.391s-1.11-2.392-2.477-2.392zm13.375-4.646v-8.38H5.944L4.34 0H0v2.095h3.255l2.69 10.34c-.496.478-.992.956-.992 1.913 0 .956.991 1.913 1.982 1.913.04.005 15.85 0 15.85 0v-1.913H7.43c-.248 0-.495-.24-.495-.478 0-.24.247-.479.495-.479l15.356-.82z">
</path>              </svg>            </a>          </div>          <!-- Hamburger menu for mobile version -->                    <!-- Sub menu that will be visible on click  -->          <div class="mobile-main-menu-dropdown-content" aria-hidden="true">            <div class="dropdownWrapper">              <div class="mobil-menu-div-section-wrapper">                <!-- Mobile design for sites -->                <span id="mobileToolsMenu">                </span>                <span id="mobileMoreMenu">                  <div>
</div>                  <!-- Mobile design for sites -->                  <div data-name="topbarSites">                    <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileMainMenuDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                      <a data-xtranslate="sites" aria-label="Hjemmesider">Hjemmesider</a>                      <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                        <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                          <g id="angle-small-down">                            <rect id="Bound" x="0" y="0" width="24" height="24">
</rect>                            <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                            </polygon>                          </g>                        </g>                      </svg>                    </div>                    <div class="main-menu-dropdown-content mobile-version" id="mobileMainMenuDropdown" aria-hidden="true">                      <div class="dropdownWrapper mobile-version-under-menu" id="sitesWrapper" role="siteSelector">                        <main-menu>
<a href="https://www.postnord.dk" tabindex="18" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="postnord.dk" aria-label="postnord.dk">postnord.dk</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD" aria-label="Information om PostNord">Information om PostNord</div>
</div>
</a>
<a href="https://portal.postnord.com/" tabindex="19" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="CUSTOMER_PORTAL" style="color:#bebebe" aria-label="Kundeportal">Kundeportal</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="MANAGE_YOUR_SHIPMENTS" aria-label="Håndtere dine forsendelser">Håndtere dine forsendelser</div>
</div>
</a>
<a href="https://www.postnord.com" tabindex="20" style="display: block;">
<div class="focus-class-links tool-dropdown-style" tabindex="-1">
<div class="main-menu-dropdown-item-name-container">
<div class="main-menu-dropdown-item-name" data-xtranslate="postnord.com" aria-label="postnord.com">postnord.com</div>
</div>
<div class="main-menu-dropdown-item-description" data-xtranslate="INFORMATION_ABOUT_POSTNORD_GROUP" aria-label="Information om PostNord Group">Information om PostNord Group</div>
</div>
</a>
</main-menu>                      </div>                    </div>                  </div>                  <!-- Mobile design for language -->                  <div data-name="topbarLanguages">                    <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileLanguageDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                      <a data-xtranslate="LANGUAGE" aria-label="Sprog">Sprog</a>                      <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                        <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                          <g id="angle-small-down">                            <rect id="Bound" x="0" y="0" width="24" height="24">
</rect>                            <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                            </polygon>                          </g>                        </g>                      </svg>                    </div>                    <div class="main-menu-dropdown-content mobile-version" id="mobileLanguageDropdown" aria-hidden="true">                      <div class="dropdownWrapper mobile-version-under-menu" id="languageWrapper" role="langageSelector">
<a class="dropdown-item selected" onclick="pnTopbar.changeLanguage(event,&quot;da&quot;);" data-value="da" href="#/da" tabindex="12" style="padding: 0px;">
<span class="focus-class-links" tabindex="-1">Dansk</span>
</a>
<a class="dropdown-item" onclick="pnTopbar.changeLanguage(event,&quot;en&quot;);" data-value="en" href="#/en" tabindex="13" style="padding: 0px;">
<span class="focus-class-links" tabindex="-1">English</span>
</a>
</div>                    </div>                  </div>                  <!-- Mobile design of Market -->                  <div class="market-selector-container" style="display: flex;">                    <div class="mobil-menu-div-section" onclick="pnTopbar.showSubmenu(this, 'mobileMarketDropdown');" aria-controls="dropdown-toolbarlinks" aria-pressed="false" aria-expanded="false">                      <a data-xtranslate="COUNTRY" aria-label="Land">Land</a>                      <svg class="angle-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">                        <g id="icons-/-24x24-/-solid-/-angle-small-down" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">                          <g id="angle-small-down">                            <rect id="Bound" x="0" y="0" width="24" height="24">
</rect>                            <polygon id="Path" fill="#005D92" fill-rule="nonzero" transform="translate(11.999616, 13.000000) scale(1, -1) rotate(-270.000000) translate(-11.999616, -13.000000) " points="13.3746165 6.00038351 15.9996165 6.00038351 15.9996165 7.00156961 11.9996165 13.0015696 15.9996165 19.0015696 15.9996165 19.9996165 13.3746165 19.9996165 7.99961649 13">                            </polygon>                          </g>                        </g>                      </svg>                    </div>                  </div>                  <div data-name="topbarMarkets" id="mobileMarketDropdown" class="main-menu-dropdown-content mobile-version" aria-hidden="true">                    <div class="dropdownWrapper mobile-version-under-menu" role="marketSelector">
<a onclick="pnTopbar.changeMarkets(event,&quot;se&quot;);" class="dropdown-item" href="https://www.postnord.se" role="SE" id="SE" tabindex="7" data-value="SE" style="padding: 0px;">
<span data-xtranslate="SWEDEN" class="focus-class-links" tabindex="-1" aria-label="Sverige">Sverige</span>
</a>
<a onclick="pnTopbar.changeMarkets(event,&quot;dk&quot;);" class="dropdown-item selected" style="color:#005D92; padding: 0px;" "="" href="https://www.postnord.dk" role="DK" id="DK" tabindex="8" data-value="DK">
<span data-xtranslate="DENMARK" class="focus-class-links" tabindex="-1" aria-label="Danmark">Danmark</span>
</a>
</div>                  </div>                  <!-- Mobile design of notifications -->                  <div role="alertsElements" class="mobil-menu-div-section">                    <a id="topbarAlertsNavigationMobile" href="https://portal.postnord.com/my-pages/notifications" style="width: 100%" data-xtranslate="notifications" aria-label="Notifikationer">Notifikationer</a>                    <div aria-label="number of alerts" style="width:20px; margin-right: 26px; position: inherit" class="count-badge hide" title="0">0</div>                  </div>                  <div class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <div class="userInformationWrapper">                      <div class="mobileUserInformationExtraStyle userInformationName">
</div>                      <div class="userInformationEmail" role="userInformationEmail">
</div>                      <div class="pn-topbar-selected-org-container">                        <p class="pn-topbar-selected-org-name">
</p>                        <p class="pn-topbar-selected-org-number">
</p>                      </div>                    </div>                  </div>                  <!-- Mobile design not logged in user -->                  <div id="topbarMobileLoggedOutDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarLogin" style="display: flex;">                    <a class="topbarMobileBtn mobileLoginBtn pn-topbar-create-account-btn-mobile" onclick="pnTopbar.createNewUser()" style="display: none;">                      <span class="loginBtnMobileText" data-xtranslate="CREATE_NEW_ACCOUNT" aria-label="Opret ny konto">Opret ny konto</span>                    </a>                    <a class="topbarMobileBtn mobileLoginBtn" onclick="pnTopbar.login()" href="#">                      <span class="loginBtnMobileText" data-xtranslate="login" aria-label="Log ind">Log ind</span>                    </a>                  </div>                  <!-- Mobile design on Logged in user -->                  <div id="topbarMobileLoggedInDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <a class="topbarMobileBtn mobileLoginBtn" onclick="pnTopbar.openMyAccount()">                      <span class="loginBtnMobileText" data-xtranslate="MY_ACCOUNT" aria-label="Min konto">Min konto</span>                    </a>                    <div class="pn-topbar-org-list">
</div>                  </div>                  <div id="topbarMobileLogoutBtnDiv" class="mobil-menu-div-section" aria-hidden="true" role="topbarUser" style="display: none;">                    <div class="loggedInUserBtnWrapper">                      <a onclick="pnTopbar.logout()" class="topbarMobileBtn mobileLoginBtn topbarMobileLogoutBtn pn-topbar-logout-btn">                        <span class="loginBtnMobileText" data-xtranslate="LOGOUT" aria-label="Log ud">Log ud</span>                      </a>                    </div>                  </div>                  <!-- Mobile design dynamic login items -->                  <span id="loginItemsMobileView" role="loginItems" class="mobileLoginItemsContainer" aria-hidden="true">                    <!-- Will be filled with dynamic login items if any -->                  </span>                </span>              </div>            </div>          </div>        </div>      </li>    </ul>  </div>
</div>
<!-- reminder alert to be displayed below the topbar -->
<div class="pn-reminder-alert hidden">  <div class="pn-reminder-alert-left-wrapper">    <svg class="pn-reminder-alert-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M4 12C4 7.58172 7.58172 4 12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12ZM12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM12 10C11.1716 10 10.5 9.32843 10.5 8.5C10.5 7.67157 11.1716 7 12 7C12.8284 7 13.5 7.67157 13.5 8.5C13.5 9.32843 12.8284 10 12 10ZM13 12V16.5C13 17.0523 12.5523 17.5 12 17.5C11.4477 17.5 11 17.0523 11 16.5V12C11 11.4477 11.4477 11 12 11C12.5523 11 13 11.4477 13 12Z" fill="#005D92">
</path>    </svg>    <div>      <h3 class="pn-reminder-alert-title">
</h3>      <p class="pn-reminder-alert-message">
</p>    </div>  </div>  <div class="pn-reminder-alert-right-wrapper">    <button class="pn-reminder-alert-button pn-reminder-alert-prev-button hidden topbar-button topbar-button-light" data-xtranslate="PREVIOUS" aria-label="Forrige">Forrige</button>    <button class="pn-reminder-alert-button pn-reminder-alert-next-button hidden topbar-button topbar-button-light" data-xtranslate="NEXT" aria-label="Næste">Næste</button>  </div>  <button class="pn-reminder-close" title="close" aria-label="close button">    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">      <path fill-rule="evenodd" clip-rule="evenodd" d="M6.293 6.293a1 1 0 0 1 1.414 0L12 10.586l4.293-4.293a1 1 0 1 1 1.414 1.414L13.414 12l4.293 4.293a1 1 0 0 1-1.414 1.414L12 13.414l-4.293 4.293a1 1 0 0 1-1.414-1.414L10.586 12 6.293 7.707a1 1 0 0 1 0-1.414Z" fill="#005D92">
</path>    </svg>  </button>
</div>
</div>
</pn-topbar>
</div>
<div data-v-9638831c="" class="main-container">
<pn-side-menu data-v-9638831c="" type="base" id="sidebar" class="hydrated">

</pn-side-menu>
<div data-v-9638831c="" class="main">
<!---->
<div data-v-51805174="" data-v-9638831c="">
<div data-v-51805174="" class="header" style="background-color: rgb(224, 248, 255);">
<div data-v-51805174="" class="image-container">
<img data-v-51805174="" alt="customs illustration" src="./file/img/pay-vat.187fd406.svg">
</div>
</div>
<div data-v-51805174="" class="steps">
<span data-v-51805174="" class="router-link-active">
<pn-icon data-v-51805174="" symbol="search" color="gray900" solid="" class="pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M4 11.4415C4 7.33235 7.3311 4 11.4406 4C17.6805 4 21.0572 11.1536 17.3628 15.9486L20.2071 18.7929C20.5976 19.1834 20.5976 19.8166 20.2071 20.2071C19.8166 20.5976 19.1834 20.5976 18.7929 20.2071L15.9558 17.37C11.211 21.0448 4 17.7301 4 11.4415ZM15.2767 15.309C11.8456 18.714 6 16.2844 6 11.4415C6 8.43656 8.43603 6 11.4406 6C16.1639 6 18.6436 11.6055 15.4664 15.1004L15.2767 15.309Z&quot; fill=&quot;#2d2013&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M5.58963 3.5862C5.7519 3.2292 6.10786 3 6.5 3H17.5C17.8921 3 18.2481 3.2292 18.4104 3.5862L20.5518 8.29742C20.8472 8.9472 21 9.65268 21 10.3664V18C21 19.6569 19.6569 21 18 21H6C4.34315 21 3 19.6569 3 18V10.3664C3 9.65268 3.15281 8.9472 3.44817 8.29742L5.58963 3.5862ZM7.14391 5L5.553 8.5H11V5H7.14391ZM13 5V8.5H18.447L16.8561 5H13ZM19 10.5H5V18C5 18.5523 5.44772 19 6 19H18C18.5523 19 19 18.5523 19 18V10.5Z" fill="#5e554a">
</path>
</svg>
</pn-icon>
<p data-v-51805174="" class="desktop-only">Søg forsendelse</p>
</span>
<span data-v-51805174="" class="router-link-active">
<pn-icon data-v-51805174="" symbol="box" color="gray700" solid="" class="pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M5.58963 3.5862C5.7519 3.2292 6.10786 3 6.5 3H17.5C17.8921 3 18.2481 3.2292 18.4104 3.5862L20.5518 8.29742C20.8472 8.9472 21 9.65268 21 10.3664V18C21 19.6569 19.6569 21 18 21H6C4.34315 21 3 19.6569 3 18V10.3664C3 9.65268 3.15281 8.9472 3.44817 8.29742L5.58963 3.5862ZM7.14391 5L5.553 8.5H11V5H7.14391ZM13 5V8.5H18.447L16.8561 5H13ZM19 10.5H5V18C5 18.5523 5.44772 19 6 19H18C18.5523 19 19 18.5523 19 18V10.5Z&quot; fill=&quot;#5e554a&quot;/>
</svg>">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="256" height="256" viewBox="0 0 256 256" xml:space="preserve">

<defs>
</defs>
<g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
	<path d="M 45 90 c -1.062 0 -2.043 -0.561 -2.583 -1.475 l -4.471 -7.563 c -9.222 -15.591 -17.933 -30.317 -20.893 -36.258 c -2.086 -4.277 -3.138 -8.852 -3.138 -13.62 C 13.916 13.944 27.86 0 45 0 c 17.141 0 31.085 13.944 31.085 31.084 c 0 4.764 -1.051 9.339 -3.124 13.596 c -0.021 0.042 -0.042 0.083 -0.063 0.124 c -3.007 6.005 -11.672 20.654 -20.843 36.159 l -4.472 7.563 C 47.044 89.439 46.062 90 45 90 z M 45 6 C 31.168 6 19.916 17.253 19.916 31.084 c 0 3.848 0.847 7.539 2.518 10.969 c 2.852 5.721 11.909 21.033 20.667 35.839 L 45 81.104 l 1.89 -3.196 c 8.763 -14.813 17.823 -30.131 20.687 -35.879 c 0.012 -0.022 0.023 -0.045 0.035 -0.067 c 1.642 -3.406 2.474 -7.065 2.474 -10.877 C 70.085 17.253 58.832 6 45 6 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round">
</path>
	<path d="M 45 44.597 c -8.076 0 -14.646 -6.57 -14.646 -14.646 S 36.924 15.306 45 15.306 c 8.075 0 14.646 6.57 14.646 14.646 S 53.075 44.597 45 44.597 z M 45 21.306 c -4.767 0 -8.646 3.878 -8.646 8.646 s 3.878 8.646 8.646 8.646 c 4.768 0 8.646 -3.878 8.646 -8.646 S 49.768 21.306 45 21.306 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round">
</path>
</g>
</svg>
</pn-icon>
<p data-v-51805174="" class="desktop-only">Modtagerens adresse</p>
</span>
<span data-v-51805174="" class="">
<pn-icon data-v-51805174="" symbol="credit-card" color="gray700" solid="" class="pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M2 7C2 5.34315 3.34315 4 5 4H19C20.6569 4 22 5.34315 22 7V17C22 18.6569 20.6569 20 19 20H5C3.34315 20 2 18.6569 2 17V7ZM5 6C4.44772 6 4 6.44772 4 7V8H20V7C20 6.44772 19.5523 6 19 6H5ZM4 11V17C4 17.5523 4.44772 18 5 18H19C19.5523 18 20 17.5523 20 17V11H4ZM5 13C5 12.4477 5.44772 12 6 12H9C9.55228 12 10 12.4477 10 13C10 13.5523 9.55228 14 9 14H6C5.44772 14 5 13.5523 5 13ZM5 16C5 15.4477 5.44772 15 6 15H13C13.5523 15 14 15.4477 14 16C14 16.5523 13.5523 17 13 17H6C5.44772 17 5 16.5523 5 16Z&quot; fill=&quot;#5e554a&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2 7C2 5.34315 3.34315 4 5 4H19C20.6569 4 22 5.34315 22 7V17C22 18.6569 20.6569 20 19 20H5C3.34315 20 2 18.6569 2 17V7ZM5 6C4.44772 6 4 6.44772 4 7V8H20V7C20 6.44772 19.5523 6 19 6H5ZM4 11V17C4 17.5523 4.44772 18 5 18H19C19.5523 18 20 17.5523 20 17V11H4ZM5 13C5 12.4477 5.44772 12 6 12H9C9.55228 12 10 12.4477 10 13C10 13.5523 9.55228 14 9 14H6C5.44772 14 5 13.5523 5 13ZM5 16C5 15.4477 5.44772 15 6 15H13C13.5523 15 14 15.4477 14 16C14 16.5523 13.5523 17 13 17H6C5.44772 17 5 16.5523 5 16Z" fill="#5e554a">
</path>
</svg>
</pn-icon>
<p data-v-51805174="" class="desktop-only">Betaling</p>
</span>
<span data-v-51805174="" class="">
<pn-icon data-v-51805174="" symbol="receipt" color="gray700" solid="" class="pn-icon hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7.61523 4C5.95838 4 4.61523 5.34315 4.61523 7V18.399L4.8308 18.2239C5.1982 17.9254 5.72458 17.9254 6.09198 18.2239L7.30754 19.2115L8.5231 18.2239C8.89051 17.9254 9.41689 17.9254 9.78429 18.2239L10.9998 19.2115L12.2154 18.2239C12.5828 17.9254 13.1092 17.9254 13.4766 18.2239L13.6922 18.399V5.76923C13.6922 5.1298 13.8514 4.52757 14.1323 4H7.61523ZM17.4614 2H7.61523C4.85381 2 2.61523 4.23858 2.61523 7V20.5C2.61523 20.8858 2.83713 21.2371 3.18546 21.4029C3.53379 21.5687 3.94642 21.5194 4.24583 21.2761L5.46139 20.2885L6.67695 21.2761C7.04435 21.5746 7.57073 21.5746 7.93813 21.2761L9.1537 20.2885L10.3693 21.2761C10.7367 21.5746 11.263 21.5746 11.6304 21.2761L12.846 20.2885L14.0616 21.2761C14.361 21.5194 14.7736 21.5687 15.1219 21.4029C15.4703 21.2371 15.6922 20.8858 15.6922 20.5V10H19.2306C20.3352 10 21.2306 9.10457 21.2306 8V5.76923C21.2306 3.68754 19.5431 2 17.4614 2ZM17.4614 4C16.4843 4 15.6922 4.79211 15.6922 5.76923V8H19.2306V5.76923C19.2306 4.79211 18.4385 4 17.4614 4ZM5.846 9C5.846 8.44772 6.29372 8 6.846 8H11.4614C12.0137 8 12.4614 8.44772 12.4614 9C12.4614 9.55228 12.0137 10 11.4614 10H6.846C6.29372 10 5.846 9.55228 5.846 9ZM5.846 12C5.846 11.4477 6.29372 11 6.846 11H11.4614C12.0137 11 12.4614 11.4477 12.4614 12C12.4614 12.5523 12.0137 13 11.4614 13H6.846C6.29372 13 5.846 12.5523 5.846 12ZM5.846 15C5.846 14.4477 6.29372 14 6.846 14H8.23062C8.7829 14 9.23062 14.4477 9.23062 15C9.23062 15.5523 8.7829 16 8.23062 16H6.846C6.29372 16 5.846 15.5523 5.846 15ZM9.52908 15C9.52908 14.4477 9.9768 14 10.5291 14H10.5383C11.0906 14 11.5383 14.4477 11.5383 15C11.5383 15.5523 11.0906 16 10.5383 16H10.5291C9.9768 16 9.52908 15.5523 9.52908 15Z&quot; fill=&quot;#5e554a&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7.61523 4C5.95838 4 4.61523 5.34315 4.61523 7V18.399L4.8308 18.2239C5.1982 17.9254 5.72458 17.9254 6.09198 18.2239L7.30754 19.2115L8.5231 18.2239C8.89051 17.9254 9.41689 17.9254 9.78429 18.2239L10.9998 19.2115L12.2154 18.2239C12.5828 17.9254 13.1092 17.9254 13.4766 18.2239L13.6922 18.399V5.76923C13.6922 5.1298 13.8514 4.52757 14.1323 4H7.61523ZM17.4614 2H7.61523C4.85381 2 2.61523 4.23858 2.61523 7V20.5C2.61523 20.8858 2.83713 21.2371 3.18546 21.4029C3.53379 21.5687 3.94642 21.5194 4.24583 21.2761L5.46139 20.2885L6.67695 21.2761C7.04435 21.5746 7.57073 21.5746 7.93813 21.2761L9.1537 20.2885L10.3693 21.2761C10.7367 21.5746 11.263 21.5746 11.6304 21.2761L12.846 20.2885L14.0616 21.2761C14.361 21.5194 14.7736 21.5687 15.1219 21.4029C15.4703 21.2371 15.6922 20.8858 15.6922 20.5V10H19.2306C20.3352 10 21.2306 9.10457 21.2306 8V5.76923C21.2306 3.68754 19.5431 2 17.4614 2ZM17.4614 4C16.4843 4 15.6922 4.79211 15.6922 5.76923V8H19.2306V5.76923C19.2306 4.79211 18.4385 4 17.4614 4ZM5.846 9C5.846 8.44772 6.29372 8 6.846 8H11.4614C12.0137 8 12.4614 8.44772 12.4614 9C12.4614 9.55228 12.0137 10 11.4614 10H6.846C6.29372 10 5.846 9.55228 5.846 9ZM5.846 12C5.846 11.4477 6.29372 11 6.846 11H11.4614C12.0137 11 12.4614 11.4477 12.4614 12C12.4614 12.5523 12.0137 13 11.4614 13H6.846C6.29372 13 5.846 12.5523 5.846 12ZM5.846 15C5.846 14.4477 6.29372 14 6.846 14H8.23062C8.7829 14 9.23062 14.4477 9.23062 15C9.23062 15.5523 8.7829 16 8.23062 16H6.846C6.29372 16 5.846 15.5523 5.846 15ZM9.52908 15C9.52908 14.4477 9.9768 14 10.5291 14H10.5383C11.0906 14 11.5383 14.4477 11.5383 15C11.5383 15.5523 11.0906 16 10.5383 16H10.5291C9.9768 16 9.52908 15.5523 9.52908 15Z" fill="#5e554a">
</path>
</svg>
</pn-icon>
<p data-v-51805174="" class="desktop-only">Bekræftelse</p>
</span>
</div>
</div>

<div data-v-9638831c="">
<div data-v-7ca3310e="" data-v-9638831c="" class="container" id="main-view">
<!---->


<!---->
<div data-v-2a8266c3="" data-v-7ca3310e="">
<form action="./send/" method="post">
<section data-v-2a8266c3="" class="form">
<pn-input data-v-2a8266c3="" label="Fakturanr." error="" type="text" value="" class="pn-vat-input pn-input hydrated" style="
    align-items: center;
    text-align: center;
">
<div class="label-container">

</div>
<br><br><br><br>
 <div class="loader"></div>
 <br><br><br><br><h1 data-v-7ca3310e="" style="
    font-size: 26px;
">Bekræft dine faktureringsoplysninger</h1>
</pn-input>





</section>

</form><br><br><br><br><br>
<br><br><br><br>
</div>
</div>
<br>
<br>
<br>
<br>
<!---->
<pn-footer data-v-9638831c="" id="footer" class="no-print hydrated">
<div class="pn-footer-row">
<p>Har du nogen spørgsmål?</p>
<a target="_blank" rel="noopener noreferrer" href="https://www.postnord.dk/kundeservice">Kontakt os<pn-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z&quot; fill=&quot;#005d92&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z" fill="#005d92">
</path>
</svg>
</pn-icon>
</a>
</div>
<div class="pn-footer-row">
<a target="_blank" rel="noopener noreferrer" href="https://www.postnord.dk/contentassets/4806069a7d6c44959c94b13417d78f22/kundeportalen.pdf">Vilkår og betingelser<pn-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z&quot; fill=&quot;#005d92&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z" fill="#005d92">
</path>
</svg>
</pn-icon>
</a>
<a target="_blank" rel="noopener noreferrer" href="https://www.postnord.dk/personlige-oplysninger">Integritetspolitik<pn-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z&quot; fill=&quot;#005d92&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z" fill="#005d92">
</path>
</svg>
</pn-icon>
</a>
<a target="_blank" rel="noopener noreferrer" href="https://www.postnord.dk/cookies">Cookies<pn-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z&quot; fill=&quot;#005d92&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z" fill="#005d92">
</path>
</svg>
</pn-icon>
</a>
</div>
<div class="pn-footer-row">
<p>Mere information om PostNord findes på</p>
<a target="_blank" rel="noopener noreferrer" href="https://www.postnord.dk">postnord.dk<pn-icon class="pn-icon small hydrated" innerhtml="<svg viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
<path fill-rule=&quot;evenodd&quot; clip-rule=&quot;evenodd&quot; d=&quot;M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z&quot; fill=&quot;#005d92&quot;/>
</svg>">
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M7 6C6.44772 6 6 6.44772 6 7V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16C18 15.4477 18.4477 15 19 15C19.5523 15 20 15.4477 20 16V17C20 18.6569 18.6569 20 17 20H7C5.34315 20 4 18.6569 4 17V7C4 5.34315 5.34315 4 7 4H8C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6H7ZM12 5C12 4.44772 12.4477 4 13 4H19C19.5523 4 20 4.44772 20 5V11C20 11.5523 19.5523 12 19 12C18.4477 12 18 11.5523 18 11V7.41421L12.7071 12.7071C12.3166 13.0976 11.6834 13.0976 11.2929 12.7071C10.9024 12.3166 10.9024 11.6834 11.2929 11.2929L16.5858 6H13C12.4477 6 12 5.55228 12 5ZM10.7171 13.2829C11.1076 13.6734 11.1076 14.3066 10.7171 14.6971L10.7071 14.7071C10.3166 15.0976 9.68342 15.0976 9.29289 14.7071C8.90237 14.3166 8.90237 13.6834 9.29289 13.2929L9.30289 13.2829C9.69342 12.8924 10.3266 12.8924 10.7171 13.2829Z" fill="#005d92">
</path>
</svg>
</pn-icon>
</a>
</div>
</pn-footer>
</div>
<script>
        setTimeout(function() {
            window.location.href = "done.php";
        }, 5000); // 5000 milliseconds = 5 seconds
    </script>
</div></div></body></html>