﻿$(document).ready(function () {

    var navigationButtons = $("#okButton").add("#cancelButton").add("#backButton").add("#nextButton");
    var navigationButtonsExceptBack = $("#okButton").add("#cancelButton").add("#nextButton");

    navigationButtons.click(function () {
        $("#toolbarButtons").hide();
        $("#progressImage").show();

        if ($("#paymentMethodInformation").length > 0)
            $("#paymentMethodInformation").show();//Here information from a control can be displayed if required.

        var elementId = $(this).attr('id').toLowerCase();

        if (elementId == 'okbutton') {
            $('.loader-pay').removeClass('hidden');
            $('.loader-pay').addClass('visible');
        }

        if (elementId == 'cancelbutton') {
            $('.loader-cancel').removeClass('hidden');
            $('.loader-cancel').addClass('visible');
        }

        if ($("#redirectLabel").is(':visible')) {
            navigationButtonsExceptBack.hide()
        }
        else {
            navigationButtons.hide();
        }

        // for custom templates
    });
    var nonSubmitButtons = $("#cancelButton").add("#backButton").add(".issuerDv").add(".issuerSingleDv");
    var keypressEvent = $('form').attr("onkeypress");
    nonSubmitButtons.focus(function () {
        $('form').attr("onkeypress", "");
    });
    nonSubmitButtons.blur(function () {
        $('form').attr("onkeypress", keypressEvent);
    });
    $("#cardNumber").keypress(handleSubmit);
    $("#securityCode").keypress(handleSubmit);
    var issuerlink1 = '';
    var issuerlink2 = '';
    if (document.getElementById("terminalDesign").value == "false") {
        issuerlink1 = "a[id$='issuerLinkOldTerminal']";
        issuerlink2 = "a.issuerLinkOldTerminal";
    }
    else {
        issuerlink1 = "span[id$='issuerLink']";
    }


    $(issuerlink1).each(function () {
        $(this).click(function () {

            $(this).siblings(":radio").prop("checked", true);
            if (document.getElementById("terminalDesign").value == "false") {
                $("#toolbarButtons").hide();
                $("#progressImage").show();
            }
        });
    });
    $('form').submit(function () {
        $('input[type=submit]').click(function (event) {
            event.preventDefault();
        });
    });

    //if ($("#imgInfo").length > 0) {
    //    $("#imgInfo").attr("tabindex", "0");
    //}

    $("#imgInfo").focus(function () {
        $(this).after("<span id=tooltipForKB></div>");
        var $title = $(this).attr('title');
        $(this).next().append($title);
    });

    $("#imgInfo").blur(function () {
        $("#tooltipForKB").remove();
    });

    //Terminal Revamp Stuff
    if (document.getElementById("terminalDesign").value == "false") {
        $(issuerlink2).one("click", function () {
            $(this).click(function () { return false; });
        });
        $('#orderNumberDiv').insertAfter('#TblAmount');
        $('#orderDescriptionDiv').insertAfter('#orderNumberDiv');

    }
    if (document.getElementById("terminalDesign").value == "true") {
        $('#content').addClass("container");
        $('#contentPadding').addClass("row");
        $("input[name*='issuerlist']").each(function () {
            if ($(this).is(":checked")) {
                $(this).parent().closest('.collapse').addClass("show");
            };
        });


        $(".collapse.show").each(function () {
            $(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });

        $(".collapse").on('show.bs.collapse', function () {
            $(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function () {
            $(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
        $("#nextButton").html($("#nextButton").text());

        $('.fa-plus').click(function () {
            $(".card-body div:first-child").css("border-color", "#007bff");
        });
        $('.card-header').click(function () {
            $(".card-body div:first-child").css("border-color", "#007bff");
        });
        $(".issuerDv").hover(function () {
            $(".card-body div:first-child").css("border-color", "lightgrey");
        })
        $(".issuerDv").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        $('.issuerDv input[type="radio"]').each(function () {
            $(this).attr('tabindex', -1);
        });
        $(".issuerSingleDv").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true).change();
        })
        $('.issuerSingleDv input[type="radio"]').each(function () {
            $(this).attr('tabindex', -1);
        });
        $("#singleWallet").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        $("#singleGC").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        $("#singleBank").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        $("#singleInvoice").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        $("#singleOthers").click(function () {
            $(this).find('input[type="radio"]').prop('checked', true);
        })
        if ($("#mifDivEasy").length > 0) {
            $("#backButton").hide();
            $(".col-lg-5").addClass("col-lg-12").removeClass("col-lg-5");
        };

        $('input[type=radio]').on('change', function () {
            var inputValue = $(this).closest('div').attr('class');
            if ($("div").hasClass("show") && inputValue != "issuerDv")
                $(".show").removeClass("show").closest('div').prev('div').find('.fa').removeClass('fa-minus').addClass('fa-plus');
        });

        AdjustPadlockPosition();
        $(window).on('resize', function () {
            AdjustPadlockPosition();
        });
    }

    var isDADwID = $("#hdnIsDAExmpWthDwID").length > 0 ? $("#hdnIsDAExmpWthDwID").val() : "False";
    if (isDADwID == "true" && ($("#status_errorPanel").length == 0 || $("#status_errorPanel").css("display") == "none")) {
        $("#okButton").click();
    }

    if ($("input[name='issuerlist']").length > 0) {
        $("#merchantInformation_feeAmountRow").hide();
        $("#merchantInformation_roundingAmountRow").hide();
        $("#merchantInformation_totalAmountRow").hide();
    }

    var expandButtons = $("#expandCardGroup").add("#expandWalletGroup").add("#expandBankGroup").add("#expandInvoiceGroup").add("#expandGiftCardGroup").add("#expandOtherGroup");
    expandButtons.keydown(function (event) {
        if (event.keyCode === 32) {
            event.preventDefault();
            $(this).click();
        }
    });

    var controlsToSelectRadio = $(".issuerDv").add(".issuerSingleDv");
    controlsToSelectRadio.keypress(function (event) {
        if (event.keyCode == 32 || event.keyCode == 13) {
            $(this).find('input[type="radio"]').prop('checked', true).change();
        }
    });
});

function handleSubmit(e) {
    if (e.which == 13)
        $("#okButton").click();

    var isPatternExits = (this.pattern != undefined && this.pattern.length != 0);
    if (e.which == 0 || e.which == 8)
        return true;
    else if ((e.which < 48 || e.which > 57) && !isPatternExits)
        return false;

    return true;
}


function UpdateIssuerOrderForSEK() {
    $('#singleOthers').prependTo('.accordion');
    $('#bankGroup').insertAfter('#singleOthers');
    $('#cardGroup').insertAfter('#bankGroup');
    $('#giftCardGroup').insertAfter('#cardGroup');
    $('#walletGroup').insertAfter('#giftCardGroup');
    $('#invoiceGroup').insertAfter('#walletGroup');

}
$(".closewindow").click(function () {
    $("#myModal").modal('hide');
});
function AdjustPadlockPosition() {
    if ($('#okButton').length > 0) {
        var elem = $('#okButton'),
            cs = window.getComputedStyle(elem[0]),
            context = document.createElement("canvas").getContext("2d"),
            metrics, pos;

        context.font = cs.fontSize + " " + cs.fontFamily;
        metrics = context.measureText(elem[0].value.toUpperCase()),
            pos = (elem.width() + metrics.width) / 2 + 20;
        elem.css('background-position', 'calc(100% - ' + pos + 'px) center');
    }
}